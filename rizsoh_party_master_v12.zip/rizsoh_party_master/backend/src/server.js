require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { connectDb } = require('./config/db');

const authRoutes = require('./modules/auth/auth.routes');
const walletRoutes = require('./modules/wallet/wallet.routes');
const giftRoutes = require('./modules/gifts/gift.routes');
const reportRoutes = require('./modules/reports/report.routes');
const paymentRoutes = require('./modules/payments/payment.routes');
const chatRoutes = require('./modules/chat/chat.routes');
const liveRoutes = require('./modules/live/live.routes');
const roomRoutes = require('./modules/rooms/room.routes');
const agencyRoutes = require('./modules/agency/agency.routes');
const familyRoutes = require('./modules/family/family.routes');
const profileRoutes = require('./modules/profile/profile.routes');

const app = express();
app.use(cors());
app.use(express.json());

app.get('/health', (_, res) => res.json({ ok: true, app: 'Rizsoh Party API' }));

app.use('/api/auth', authRoutes);
app.use('/api/wallet', walletRoutes);
app.use('/api/gifts', giftRoutes);
app.use('/api/reports', reportRoutes);
app.use('/api/payments', paymentRoutes);

app.use('/api/profile', profileRoutes);
app.use('/api/family', familyRoutes);
app.use('/api/agency', agencyRoutes);
app.use('/api/rooms', roomRoutes);
app.use('/api/live', liveRoutes);
app.use('/api/chat', chatRoutes);

const port = process.env.PORT || 4000;
connectDb()
  .then(() => app.listen(port, () => console.log(`API on ${port}`)))
  .catch(err => {
    console.error('DB connection failed', err);
    process.exit(1);
  });
