class AgoraEngineService {
  Future<void> initVoiceRoom({
    required String appId,
    required String token,
    required String channelId,
    required String uid,
  }) async {
    // TODO: plug in agora_rtc_engine package
  }

  Future<void> initLive({
    required String appId,
    required String token,
    required String channelId,
    required String uid,
    required bool isHost,
  }) async {
    // TODO: plug in agora live broadcasting profile
  }

  Future<void> leave() async {}
}
