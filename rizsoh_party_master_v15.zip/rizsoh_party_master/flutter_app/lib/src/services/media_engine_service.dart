import 'agora_engine_service.dart';
import 'zego_engine_service.dart';

class MediaEngineService {
  final _agora = AgoraEngineService();
  final _zego = ZegoEngineService();

  Future<void> initVoiceRoom({
    required String provider,
    required String appId,
    required String token,
    required String channelId,
    required String uid,
  }) async {
    if (provider.toLowerCase() == 'zego') {
      return _zego.initVoiceRoom(appId: appId, token: token, channelId: channelId, uid: uid);
    }
    return _agora.initVoiceRoom(appId: appId, token: token, channelId: channelId, uid: uid);
  }

  Future<void> initLive({
    required String provider,
    required String appId,
    required String token,
    required String channelId,
    required String uid,
    required bool isHost,
  }) async {
    if (provider.toLowerCase() == 'zego') {
      return _zego.initLive(appId: appId, token: token, channelId: channelId, uid: uid, isHost: isHost);
    }
    return _agora.initLive(appId: appId, token: token, channelId: channelId, uid: uid, isHost: isHost);
  }

  Future<void> leave() async {
    await _agora.leave();
    await _zego.leave();
  }
}
