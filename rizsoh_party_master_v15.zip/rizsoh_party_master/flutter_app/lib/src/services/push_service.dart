class PushService {
  Future<void> init() async {
    // TODO: initialize Firebase here
    // Firebase.initializeApp();
    // request notification permissions
    // fetch FCM token and send to backend /api/push/register-token
  }
}
