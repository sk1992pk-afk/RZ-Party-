class ZegoEngineService {
  Future<void> initVoiceRoom({
    required String appId,
    required String token,
    required String channelId,
    required String uid,
  }) async {
    // TODO: plug in zego_uikit / express engine
  }

  Future<void> initLive({
    required String appId,
    required String token,
    required String channelId,
    required String uid,
    required bool isHost,
  }) async {
    // TODO: plug in zego live streaming flow
  }

  Future<void> leave() async {}
}
