import 'package:flutter/material.dart';
import '../chat/inbox_list_screen.dart';
import '../social/family_list_screen.dart';
import '../social/room_list_screen.dart';
import '../social/live_list_screen.dart';
import '../../features/profile/edit_profile_screen.dart';

class MainShellScreen extends StatefulWidget {
  const MainShellScreen({super.key});

  @override
  State<MainShellScreen> createState() => _MainShellScreenState();
}

class _MainShellScreenState extends State<MainShellScreen> {
  int index = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      const RoomListScreen(),
      const LiveListScreen(),
      const InboxListScreen(),
      const FamilyListScreen(),
      const EditProfileScreen(),
    ];
    return Scaffold(
      body: pages[index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (v) => setState(() => index = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.mic), label: 'Rooms'),
          NavigationDestination(icon: Icon(Icons.live_tv), label: 'Live'),
          NavigationDestination(icon: Icon(Icons.chat), label: 'Inbox'),
          NavigationDestination(icon: Icon(Icons.groups), label: 'Family'),
          NavigationDestination(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}
