# Android production prep

## AndroidManifest permissions
Add these permissions in `android/app/src/main/AndroidManifest.xml`:
- INTERNET
- RECORD_AUDIO
- CAMERA
- BLUETOOTH / BLUETOOTH_CONNECT if required by SDK
- POST_NOTIFICATIONS (Android 13+)

## Firebase
- add `google-services.json` under `android/app/`
- add Gradle Google Services plugin
- initialize Firebase in Flutter startup

## Signing
Create `android/key.properties`:
storePassword=YOUR_PASSWORD
keyPassword=YOUR_PASSWORD
keyAlias=upload
storeFile=../app/upload-keystore.jks

## Build
flutter pub get
flutter build apk --release
