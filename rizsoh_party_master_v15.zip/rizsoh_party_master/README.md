# Rizsoh Party Master v15 — Block 10

## Added in this block
- backend role middleware (`requireRole`)
- admin dashboard scaffold endpoints with role checks
- push token registration endpoints scaffold
- main Flutter bottom navigation shell
- provider-based media service split for Agora/Zego
- Firebase push initialization placeholder
- Android permission + release notes scaffold
- AndroidManifest production permission scaffold
- final packaging structure prep for APK build

## Production checklist before actual APK
1. Choose one RTC provider: Agora or Zego.
2. Add the real Flutter SDK package and implement engine service methods.
3. Replace demo RTC token endpoints with secure token generation.
4. Connect `PushService` to Firebase and register device tokens to backend.
5. Wire `MainShellScreen` as post-login app home.
6. Add real admin auth roles to user model and middleware population.
7. Configure Android signing + `google-services.json`.
8. Run `flutter build apk --release`.

## Suggested next implementation pass
- patch `main.dart` and app router to land authenticated users in `MainShellScreen`
- add real Firebase initialization code
- add real Agora or Zego implementation code
- compile and fix build errors in a local Flutter environment
