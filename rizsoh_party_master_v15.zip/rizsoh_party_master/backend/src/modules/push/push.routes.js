const router = require('express').Router();
const { auth } = require('../../middleware/auth');

const deviceTokens = new Map();

router.post('/register-token', auth, async (req, res) => {
  const { token, platform } = req.body;
  deviceTokens.set(req.user.id, { token, platform, updatedAt: new Date().toISOString() });
  res.json({ ok: true });
});

router.get('/my-token', auth, async (req, res) => {
  res.json({ token: deviceTokens.get(req.user.id) || null });
});

module.exports = router;
