const router = require('express').Router();
const { auth } = require('../../middleware/auth');
const { requireRole } = require('../../middleware/roles');

router.get('/dashboard', auth, requireRole('admin', 'superadmin'), async (_, res) => {
  res.json({
    stats: {
      users: 0,
      rooms: 0,
      lives: 0,
      reportsPending: 0,
      withdrawalsPending: 0
    }
  });
});

router.get('/moderation/overview', auth, requireRole('admin', 'superadmin', 'manager'), async (_, res) => {
  res.json({
    roomBans: [],
    mutes: [],
    kicks: [],
    liveWarnings: []
  });
});

module.exports = router;
