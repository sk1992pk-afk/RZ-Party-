import 'package:flutter/material.dart';

class RoomModerationPanelScreen extends StatelessWidget {
  const RoomModerationPanelScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final actions = const [
      'Mute user for 10 minutes',
      'Kick user from room',
      'Ban user from room',
      'Lock seat request',
      'Approve seat request',
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('Room Moderation')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: actions.map((e) => Card(child: ListTile(title: Text(e), trailing: const Icon(Icons.chevron_right)))).toList(),
      ),
    );
  }
}
