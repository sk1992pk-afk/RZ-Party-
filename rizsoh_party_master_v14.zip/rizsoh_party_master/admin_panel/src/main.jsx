import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom'
import UsersPage from './pages/UsersPage'
import RoomsPage from './pages/RoomsPage'
import WalletPage from './pages/WalletPage'
import FamiliesPage from './pages/FamiliesPage'
import WithdrawalsPage from './pages/WithdrawalsPage'
import AgencyPage from './pages/AgencyPage'
import RechargeReviewPage from './pages/RechargeReviewPage'
import PushPage from './pages/PushPage'
import ModerationPage from './pages/ModerationPage'
import SettlementsPage from './pages/SettlementsPage'
import VipLevelsPage from './pages/VipLevelsPage'
import GiftTransactionsPage from './pages/GiftTransactionsPage'
import PaymentActionsPage from './pages/PaymentActionsPage'
import ReportsPage from './pages/ReportsPage'
import ReportsTablePage from './pages/ReportsTablePage'

function Dashboard() {
  return (
    <div style={{padding:24}}>
      <h1>Rizsoh Party Admin</h1>
      <p>Expanded admin scaffold for moderation, settlements, VIP systems, gift transactions and payment approval flows.</p>
    </div>
  )
}

function App() {
  return (
    <BrowserRouter>
      <div style={{display:'flex', minHeight:'100vh'}}>
        <aside style={{width:300, borderRight:'1px solid #eee', padding:16}}>
          <h3>Admin Panel</h3>
          <div style={{display:'grid', gap:10}}>
            <Link to="/">Dashboard</Link>
            <Link to="/users">Users</Link>
            <Link to="/rooms">Rooms</Link>
            <Link to="/wallet">Wallet</Link>
            <Link to="/families">Families</Link>
            <Link to="/agency">Agency</Link>
            <Link to="/recharge-review">Recharge Review</Link>
            <Link to="/withdrawals">Withdrawals</Link>
            <Link to="/push">Push</Link>
            <Link to="/moderation">Moderation</Link>
            <Link to="/settlements">Settlements</Link>
            <Link to="/vip-levels">VIP / Levels</Link>
            <Link to="/gift-transactions">Gift Transactions</Link>
            <Link to="/payment-actions">Payment Actions</Link>
            <Link to="/reports">Reports</Link>
            <Link to="/reports-table">Reports Table</Link>
          </div>
        </aside>
        <main style={{flex:1}}>
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/users" element={<UsersPage />} />
            <Route path="/rooms" element={<RoomsPage />} />
            <Route path="/wallet" element={<WalletPage />} />
            <Route path="/families" element={<FamiliesPage />} />
            <Route path="/agency" element={<AgencyPage />} />
            <Route path="/recharge-review" element={<RechargeReviewPage />} />
            <Route path="/withdrawals" element={<WithdrawalsPage />} />
            <Route path="/push" element={<PushPage />} />
            <Route path="/moderation" element={<ModerationPage />} />
            <Route path="/settlements" element={<SettlementsPage />} />
            <Route path="/vip-levels" element={<VipLevelsPage />} />
            <Route path="/gift-transactions" element={<GiftTransactionsPage />} />
            <Route path="/payment-actions" element={<PaymentActionsPage />} />
            <Route path="/reports" element={<ReportsPage />} />
            <Route path="/reports-table" element={<ReportsTablePage />} />
          </Routes>
        </main>
      </div>
    </BrowserRouter>
  )
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />)
