export default function UsersPage() {
  return <div style={{padding:24}}><h2>Users</h2><p>Manage users, bans, profile status, verification and wallet snapshots.</p></div>
}
