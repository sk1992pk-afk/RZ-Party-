export default function SettlementsPage() {
  return (
    <div style={{padding:24}}>
      <h2>Agency / Host Settlements</h2>
      <p>Manage monthly host earnings, agency share, payout status and settlement history.</p>
    </div>
  )
}
