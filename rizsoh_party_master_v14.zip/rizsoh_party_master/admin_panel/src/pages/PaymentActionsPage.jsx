export default function PaymentActionsPage() {
  return (
    <div style={{padding:24}}>
      <h2>Payment Approval Actions</h2>
      <p>Approve recharge requests, approve withdrawals and audit all payment review actions.</p>
    </div>
  )
}
