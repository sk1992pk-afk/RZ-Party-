export default function ReportsTablePage() {
  const rows = [
    { id: 'rep_1', type: 'user', target: 'u2', reason: 'abuse', status: 'pending' },
    { id: 'rep_2', type: 'room', target: 'r1', reason: 'spam', status: 'reviewed' },
    { id: 'rep_3', type: 'live', target: 'live_1', reason: 'harassment', status: 'pending' },
  ];

  return (
    <div style={{padding:24}}>
      <h2>Reports Data Table</h2>
      <div style={{display:'flex', gap:12, marginBottom:16}}>
        <button>All</button><button>Pending</button><button>Reviewed</button>
      </div>
      <table border="1" cellPadding="8" style={{borderCollapse:'collapse', width:'100%'}}>
        <thead>
          <tr><th>ID</th><th>Type</th><th>Target</th><th>Reason</th><th>Status</th><th>Action</th></tr>
        </thead>
        <tbody>
          {rows.map(r => (
            <tr key={r.id}>
              <td>{r.id}</td><td>{r.type}</td><td>{r.target}</td><td>{r.reason}</td><td>{r.status}</td>
              <td><button>Review</button></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
