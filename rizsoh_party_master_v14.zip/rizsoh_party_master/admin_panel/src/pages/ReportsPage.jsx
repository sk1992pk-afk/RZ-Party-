export default function ReportsPage() {
  return (
    <div style={{padding:24}}>
      <h2>Safety Reports</h2>
      <p>Review user reports, room reports, live-stream reports, abusive behavior flags and moderation escalation items.</p>
    </div>
  )
}
