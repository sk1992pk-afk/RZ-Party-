export default function WithdrawalsPage() {
  return <div style={{padding:24}}><h2>Withdrawals</h2><p>Approve or reject host withdrawal requests and track payout history.</p></div>
}
