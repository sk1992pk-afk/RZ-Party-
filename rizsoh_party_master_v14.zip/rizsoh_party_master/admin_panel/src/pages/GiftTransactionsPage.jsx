export default function GiftTransactionsPage() {
  return (
    <div style={{padding:24}}>
      <h2>Gift Transactions</h2>
      <p>Track sent gifts, coin deductions, receiver diamond credits, room/live gift analytics and refunds if needed.</p>
    </div>
  )
}
