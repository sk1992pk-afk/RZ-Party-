export default function RoomsPage() {
  return <div style={{padding:24}}><h2>Rooms</h2><p>Monitor voice rooms, hosts, room locks, reports, mute/ban actions.</p></div>
}
