export default function FamiliesPage() {
  return <div style={{padding:24}}><h2>Families & Agencies</h2><p>Manage families, agency requests, leaders, settlements and violations.</p></div>
}
