export default function PushPage() {
  return <div style={{padding:24}}><h2>Push Notifications</h2><p>Send announcements, campaign notifications and moderation alerts.</p></div>
}
