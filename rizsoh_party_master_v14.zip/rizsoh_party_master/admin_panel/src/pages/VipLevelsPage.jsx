export default function VipLevelsPage() {
  return (
    <div style={{padding:24}}>
      <h2>VIP / Levels / Badges</h2>
      <p>Configure VIP benefits, level rewards, user frames, profile badges and seasonal labels.</p>
    </div>
  )
}
