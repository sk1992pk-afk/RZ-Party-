export default function AgencyPage() {
  return <div style={{padding:24}}><h2>Agency Center</h2><p>Review agencies, hosts, monthly settlements and host applications.</p></div>
}
