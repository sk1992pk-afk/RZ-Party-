export default function ModerationPage() {
  return (
    <div style={{padding:24}}>
      <h2>Room Moderation</h2>
      <p>Review mute, kick, ban and room safety actions. Add filters for room ID, host, target user and action type.</p>
    </div>
  )
}
