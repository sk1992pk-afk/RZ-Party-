const { db, makeId } = require('../db/inMemoryDb');

function findUser(userId) {
  return db.users.find(u => u.id === userId);
}

function addWalletTx({ userId, type, amount, currency, meta = {} }) {
  const tx = {
    id: makeId('tx'),
    userId,
    type,
    amount,
    currency,
    meta,
    createdAt: new Date().toISOString()
  };
  db.walletTransactions.unshift(tx);
  return tx;
}

function spendCoins(userId, amount, meta = {}) {
  const user = findUser(userId);
  if (!user) throw new Error('User not found');
  if (user.coins < amount) throw new Error('Insufficient coins');
  user.coins -= amount;
  return addWalletTx({ userId, type: 'spend', amount, currency: 'coins', meta });
}

function addDiamonds(userId, amount, meta = {}) {
  const user = findUser(userId);
  if (!user) throw new Error('User not found');
  user.diamonds += amount;
  return addWalletTx({ userId, type: 'diamond_credit', amount, currency: 'diamonds', meta });
}

function addCoins(userId, amount, meta = {}) {
  const user = findUser(userId);
  if (!user) throw new Error('User not found');
  user.coins += amount;
  return addWalletTx({ userId, type: 'coin_credit', amount, currency: 'coins', meta });
}

module.exports = {
  findUser,
  addWalletTx,
  spendCoins,
  addDiamonds,
  addCoins
};
