const { db, makeId } = require('../db/inMemoryDb');

function addAction({ roomId, targetUserId, actionType, actionBy, reason = '', expiresAt = null }) {
  const action = {
    id: makeId('mod'),
    roomId,
    targetUserId,
    actionType,
    actionBy,
    reason,
    expiresAt,
    createdAt: new Date().toISOString()
  };
  db.roomModeration.unshift(action);
  return action;
}

function muteUser({ roomId, targetUserId, actionBy, minutes = 10, reason = '' }) {
  const expiresAt = new Date(Date.now() + minutes * 60 * 1000).toISOString();
  return addAction({ roomId, targetUserId, actionType: 'mute', actionBy, reason, expiresAt });
}

function kickUser({ roomId, targetUserId, actionBy, reason = '' }) {
  return addAction({ roomId, targetUserId, actionType: 'kick', actionBy, reason });
}

function banUser({ roomId, targetUserId, actionBy, reason = '' }) {
  return addAction({ roomId, targetUserId, actionType: 'ban', actionBy, reason });
}

module.exports = { addAction, muteUser, kickUser, banUser };
