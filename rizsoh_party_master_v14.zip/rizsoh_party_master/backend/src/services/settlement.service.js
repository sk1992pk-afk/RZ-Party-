const { db, makeId } = require('../db/inMemoryDb');

function createSettlement({ agencyId, hostUserId, monthKey, grossEarnings }) {
  const agencyShare = Math.round(grossEarnings * 0.2);
  const hostShare = grossEarnings - agencyShare;
  const row = {
    id: makeId('set'),
    agencyId,
    hostUserId,
    monthKey,
    grossEarnings,
    agencyShare,
    hostShare,
    status: 'pending',
    createdAt: new Date().toISOString()
  };
  db.settlements.unshift(row);
  return row;
}

function listSettlements() {
  return db.settlements;
}

module.exports = { createSettlement, listSettlements };
