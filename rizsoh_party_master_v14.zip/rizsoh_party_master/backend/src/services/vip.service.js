const { db } = require('../db/inMemoryDb');

function getVipBenefits(vipLevel = 0) {
  const table = {
    0: ['basic room access'],
    1: ['basic room access', 'entry badge'],
    3: ['entry badge', 'priority room seat', 'basic frame'],
    5: ['premium frame', 'special badge', 'room highlight'],
    8: ['super VIP badge', 'exclusive gifts', 'priority support']
  };
  return table[vipLevel] || ['custom benefits'];
}

function getUserProfileCard(userId) {
  const user = db.users.find(u => u.id === userId);
  if (!user) return null;
  return {
    id: user.id,
    name: user.name,
    vipLevel: user.vipLevel,
    level: user.level,
    badges: user.badges,
    benefits: getVipBenefits(user.vipLevel)
  };
}

module.exports = { getVipBenefits, getUserProfileCard };
