const { db, makeId } = require('../db/inMemoryDb');
const { spendCoins, addDiamonds } = require('./wallet.service');

function sendGift({ fromUserId, toUserId, targetType, targetId, giftId, qty = 1 }) {
  const gift = db.gifts.find(g => g.id === giftId);
  if (!gift) throw new Error('Gift not found');

  const totalCoins = gift.priceCoins * qty;
  spendCoins(fromUserId, totalCoins, {
    reason: 'gift_send',
    targetType,
    targetId,
    giftId,
    qty
  });

  const diamondReward = Math.floor(totalCoins * 0.5);
  addDiamonds(toUserId, diamondReward, {
    reason: 'gift_receive',
    fromUserId,
    giftId,
    qty
  });

  const tx = {
    id: makeId('gift'),
    fromUserId,
    toUserId,
    targetType,
    targetId,
    giftId,
    qty,
    totalCoins,
    diamondReward,
    createdAt: new Date().toISOString()
  };
  db.giftTransactions.unshift(tx);
  return tx;
}

module.exports = { sendGift };
