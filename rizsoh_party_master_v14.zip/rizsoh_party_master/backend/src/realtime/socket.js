const { Server } = require('socket.io');

function setupSocket(httpServer) {
  const io = new Server(httpServer, {
    cors: { origin: '*', methods: ['GET', 'POST'] }
  });

  io.on('connection', (socket) => {
    socket.on('join_room', ({ roomId, userId }) => {
      socket.join(`room:${roomId}`);
      io.to(`room:${roomId}`).emit('room_user_joined', { roomId, userId });
    });

    socket.on('leave_room', ({ roomId, userId }) => {
      socket.leave(`room:${roomId}`);
      io.to(`room:${roomId}`).emit('room_user_left', { roomId, userId });
    });

    socket.on('room_message', ({ roomId, message }) => {
      io.to(`room:${roomId}`).emit('room_message', { roomId, message });
    });

    socket.on('room_gift', ({ roomId, gift }) => {
      io.to(`room:${roomId}`).emit('room_gift', { roomId, gift });
    });

    socket.on('host_mute_user', ({ roomId, targetUserId, minutes }) => {
      io.to(`room:${roomId}`).emit('host_mute_user', { roomId, targetUserId, minutes });
    });

    socket.on('host_kick_user', ({ roomId, targetUserId }) => {
      io.to(`room:${roomId}`).emit('host_kick_user', { roomId, targetUserId });
    });

    socket.on('join_live', ({ liveId, userId }) => {
      socket.join(`live:${liveId}`);
      io.to(`live:${liveId}`).emit('live_viewer_joined', { liveId, userId });
    });

    socket.on('leave_live', ({ liveId, userId }) => {
      socket.leave(`live:${liveId}`);
      io.to(`live:${liveId}`).emit('live_viewer_left', { liveId, userId });
    });

    socket.on('live_comment', ({ liveId, comment }) => {
      io.to(`live:${liveId}`).emit('live_comment', { liveId, comment });
    });

    socket.on('live_gift', ({ liveId, gift }) => {
      io.to(`live:${liveId}`).emit('live_gift', { liveId, gift });
    });
  });

  return io;
}

module.exports = { setupSocket };
