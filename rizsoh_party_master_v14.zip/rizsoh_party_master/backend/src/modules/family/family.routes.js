const router = require('express').Router();
const { auth } = require('../../middleware/auth');
const Family = require('../../models/Family');

router.get('/', auth, async (_, res) => {
  const rows = await Family.find().sort({ createdAt: -1 }).limit(100);
  res.json(rows);
});

router.post('/', auth, async (req, res) => {
  const row = await Family.create({
    name: req.body.name,
    bio: req.body.bio || '',
    logo: req.body.logo || '',
    ownerUserId: req.user.id,
    members: [{ userId: req.user.id, role: 'owner' }]
  });
  res.json({ message: 'family created', family: row });
});

router.post('/:id/join', auth, async (req, res) => {
  const family = await Family.findById(req.params.id);
  if (!family) return res.status(404).json({ message: 'Family not found' });
  const exists = family.members.find(m => String(m.userId) === req.user.id);
  if (!exists) family.members.push({ userId: req.user.id, role: 'member' });
  await family.save();
  res.json({ message: 'joined family', family });
});

module.exports = router;
