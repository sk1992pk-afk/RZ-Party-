const router = require('express').Router();
const { auth } = require('../../middleware/auth');
const User = require('../../models/User');

router.get('/me', auth, async (req, res) => {
  const user = await User.findById(req.user.id).select('-passwordHash');
  res.json(user);
});

router.patch('/me', auth, async (req, res) => {
  const allowed = ['name','avatar','country','language'];
  const update = {};
  for (const k of allowed) if (req.body[k] !== undefined) update[k] = req.body[k];
  const user = await User.findByIdAndUpdate(req.user.id, update, { new: true }).select('-passwordHash');
  res.json({ message: 'profile updated', user });
});

module.exports = router;
