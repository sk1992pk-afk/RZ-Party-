const router = require('express').Router();
const { getVipBenefits, getUserProfileCard } = require('../../services/vip.service');

router.get('/benefits/:vipLevel', async (req, res) => {
  const vipLevel = Number(req.params.vipLevel || 0);
  res.json({ vipLevel, benefits: getVipBenefits(vipLevel) });
});

router.get('/profile-card/:userId', async (req, res) => {
  const card = getUserProfileCard(req.params.userId);
  if (!card) return res.status(404).json({ error: 'User not found' });
  res.json(card);
});

module.exports = router;
