const router = require('express').Router();
const { auth, adminOnly } = require('../../middleware/auth');
const RechargeRequest = require('../../models/RechargeRequest');
const WithdrawRequest = require('../../models/WithdrawRequest');
const WalletTransaction = require('../../models/WalletTransaction');
const User = require('../../models/User');

router.post('/recharge', auth, async (req, res) => {
  const row = await RechargeRequest.create({
    userId: req.user.id,
    amount: Number(req.body.amount || 0),
    method: req.body.method || 'JazzCash',
    senderAccount: req.body.senderAccount || '',
    transactionId: req.body.transactionId || '',
    proofImage: req.body.proofImage || '',
  });
  res.json({ message: 'recharge request submitted', request: row });
});

router.get('/recharge/my', auth, async (req, res) => {
  const rows = await RechargeRequest.find({ userId: req.user.id }).sort({ createdAt: -1 });
  res.json(rows);
});

router.post('/withdraw', auth, async (req, res) => {
  const row = await WithdrawRequest.create({
    userId: req.user.id,
    amount: Number(req.body.amount || 0),
    method: req.body.method || 'JazzCash',
    accountTitle: req.body.accountTitle || '',
    accountNumber: req.body.accountNumber || '',
  });
  res.json({ message: 'withdraw request submitted', request: row });
});

router.get('/withdraw/my', auth, async (req, res) => {
  const rows = await WithdrawRequest.find({ userId: req.user.id }).sort({ createdAt: -1 });
  res.json(rows);
});

router.get('/admin/recharges', auth, adminOnly, async (_, res) => {
  const rows = await RechargeRequest.find().sort({ createdAt: -1 }).limit(500);
  res.json(rows);
});

router.patch('/admin/recharges/:id/review', auth, adminOnly, async (req, res) => {
  const row = await RechargeRequest.findById(req.params.id);
  if (!row) return res.status(404).json({ message: 'Recharge request not found' });

  row.status = req.body.status || row.status;
  row.reviewNote = req.body.reviewNote || '';
  row.reviewedBy = req.user.id;
  await row.save();

  if (row.status === 'approved') {
    const user = await User.findById(row.userId);
    if (user) {
      user.wallet.coins += Number(row.amount || 0);
      await user.save();
      await WalletTransaction.create({
        userId: user._id,
        type: 'recharge_approved',
        amount: row.amount,
        currency: 'coins',
        direction: 'credit',
        meta: { rechargeRequestId: row._id.toString(), method: row.method }
      });
    }
  }

  res.json({ message: 'recharge reviewed', request: row });
});

router.get('/admin/withdraws', auth, adminOnly, async (_, res) => {
  const rows = await WithdrawRequest.find().sort({ createdAt: -1 }).limit(500);
  res.json(rows);
});

router.patch('/admin/withdraws/:id/review', auth, adminOnly, async (req, res) => {
  const row = await WithdrawRequest.findById(req.params.id);
  if (!row) return res.status(404).json({ message: 'Withdraw request not found' });

  row.status = req.body.status || row.status;
  row.reviewNote = req.body.reviewNote || '';
  row.reviewedBy = req.user.id;
  await row.save();

  res.json({ message: 'withdraw reviewed', request: row });
});

module.exports = router;
