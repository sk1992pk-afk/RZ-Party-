const router = require('express').Router();
const { db, makeId } = require('../../db/inMemoryDb');
const { addCoins, addWalletTx } = require('../../services/wallet.service');

router.post('/approve-recharge/:requestId', async (req, res) => {
  const row = db.rechargeRequests.find(r => r.id === req.params.requestId);
  if (!row) return res.status(404).json({ error: 'Recharge request not found' });
  row.status = 'approved';
  addCoins(row.userId, row.amount * 2, { reason: 'approved_recharge', requestId: row.id });
  res.json({ message: 'recharge approved', row });
});

router.post('/approve-withdraw/:requestId', async (req, res) => {
  const row = db.withdrawRequests.find(r => r.id === req.params.requestId);
  if (!row) return res.status(404).json({ error: 'Withdraw request not found' });
  row.status = 'approved';
  addWalletTx({
    userId: row.userId,
    type: 'withdraw_approved',
    amount: row.amount,
    currency: 'PKR',
    meta: { requestId: row.id }
  });
  res.json({ message: 'withdraw approved', row });
});

module.exports = router;
