const router = require('express').Router();
const { db } = require('../../db/inMemoryDb');
const { muteUser, kickUser, banUser } = require('../../services/moderation.service');

router.get('/:roomId/actions', async (req, res) => {
  const actions = db.roomModeration.filter(a => a.roomId === req.params.roomId);
  res.json(actions);
});

router.post('/:roomId/mute', async (req, res) => {
  const { targetUserId, actionBy, minutes, reason } = req.body;
  try {
    const action = muteUser({ roomId: req.params.roomId, targetUserId, actionBy, minutes, reason });
    res.json({ message: 'user muted', action });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

router.post('/:roomId/kick', async (req, res) => {
  const { targetUserId, actionBy, reason } = req.body;
  try {
    const action = kickUser({ roomId: req.params.roomId, targetUserId, actionBy, reason });
    res.json({ message: 'user kicked', action });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

router.post('/:roomId/ban', async (req, res) => {
  const { targetUserId, actionBy, reason } = req.body;
  try {
    const action = banUser({ roomId: req.params.roomId, targetUserId, actionBy, reason });
    res.json({ message: 'user banned', action });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

module.exports = router;
