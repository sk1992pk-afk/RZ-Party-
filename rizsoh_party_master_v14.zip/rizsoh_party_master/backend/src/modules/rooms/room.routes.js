const router = require('express').Router();
const { auth } = require('../../middleware/auth');
const Room = require('../../models/Room');

router.get('/', auth, async (_, res) => {
  const rows = await Room.find().sort({ createdAt: -1 }).limit(100);
  res.json(rows);
});

router.post('/', auth, async (req, res) => {
  const row = await Room.create({
    title: req.body.title,
    cover: req.body.cover || '',
    ownerUserId: req.user.id,
    type: req.body.type || 'voice',
    language: req.body.language || 'en',
    seats: req.body.seats || 8,
  });
  res.json({ message: 'room created', room: row });
});

module.exports = router;
