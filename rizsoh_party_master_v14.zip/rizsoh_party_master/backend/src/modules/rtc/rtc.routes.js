const router = require('express').Router();
const { auth } = require('../../middleware/auth');

router.post('/room-token', auth, async (req, res) => {
  const { roomId, uid } = req.body;
  res.json({
    provider: process.env.RTC_PROVIDER || 'agora',
    roomId,
    uid,
    token: `demo-room-token-${roomId}-${uid}`,
    appId: process.env.RTC_APP_ID || 'demo_app_id'
  });
});

router.post('/live-token', auth, async (req, res) => {
  const { liveId, uid, role } = req.body;
  res.json({
    provider: process.env.RTC_PROVIDER || 'agora',
    liveId,
    uid,
    role: role || 'audience',
    token: `demo-live-token-${liveId}-${uid}`,
    appId: process.env.RTC_APP_ID || 'demo_app_id'
  });
});

module.exports = router;
