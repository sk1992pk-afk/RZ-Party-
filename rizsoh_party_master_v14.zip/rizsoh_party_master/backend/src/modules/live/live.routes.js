const router = require('express').Router();
const { auth } = require('../../middleware/auth');
const LiveSession = require('../../models/LiveSession');

router.get('/', auth, async (_, res) => {
  const rows = await LiveSession.find().sort({ createdAt: -1 }).limit(100);
  res.json(rows);
});

router.post('/start', auth, async (req, res) => {
  const row = await LiveSession.create({
    hostUserId: req.user.id,
    title: req.body.title,
    cover: req.body.cover || '',
  });
  res.json({ message: 'live started', live: row });
});

router.patch('/:id/end', auth, async (req, res) => {
  const row = await LiveSession.findByIdAndUpdate(req.params.id, { status: 'ended' }, { new: true });
  res.json({ message: 'live ended', live: row });
});

module.exports = router;
