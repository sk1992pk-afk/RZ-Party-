const router = require('express').Router();

router.post('/host/start', async (req, res) => {
  res.json({ message: 'Host live started', live: { id: 'host_live_1', ...req.body } });
});

router.post('/host/end', async (req, res) => {
  res.json({ message: 'Host live ended', payload: req.body });
});

router.post('/host/kick-viewer', async (req, res) => {
  res.json({ message: 'Viewer kicked from live', payload: req.body });
});

module.exports = router;
