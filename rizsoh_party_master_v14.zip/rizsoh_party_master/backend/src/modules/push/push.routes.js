const router = require('express').Router();

router.post('/register', async (req, res) => {
  const { userId, fcmToken, platform } = req.body;
  res.json({ message: 'Push token registered', userId, fcmToken, platform });
});

router.post('/send-test', async (req, res) => {
  res.json({ message: 'Test push queued', payload: req.body });
});

module.exports = router;
