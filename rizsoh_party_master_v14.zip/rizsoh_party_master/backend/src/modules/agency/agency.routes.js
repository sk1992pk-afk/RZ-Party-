const router = require('express').Router();
const { auth } = require('../../middleware/auth');
const Agency = require('../../models/Agency');

router.get('/', auth, async (_, res) => {
  const rows = await Agency.find().sort({ createdAt: -1 }).limit(100);
  res.json(rows);
});

router.post('/', auth, async (req, res) => {
  const row = await Agency.create({
    name: req.body.name,
    code: req.body.code,
    ownerUserId: req.user.id,
    hosts: [{ userId: req.user.id }]
  });
  res.json({ message: 'agency created', agency: row });
});

router.post('/:id/join', auth, async (req, res) => {
  const agency = await Agency.findById(req.params.id);
  if (!agency) return res.status(404).json({ message: 'Agency not found' });
  const exists = agency.hosts.find(h => String(h.userId) === req.user.id);
  if (!exists) agency.hosts.push({ userId: req.user.id });
  await agency.save();
  res.json({ message: 'joined agency', agency });
});

module.exports = router;
