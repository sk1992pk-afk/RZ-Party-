const router = require('express').Router();
const WalletTransaction = require('../../models/WalletTransaction');
const { auth } = require('../../middleware/auth');

router.get('/transactions', auth, async (req, res) => {
  const rows = await WalletTransaction.find({ userId: req.user.id }).sort({ createdAt: -1 }).limit(200);
  res.json(rows);
});

module.exports = router;
