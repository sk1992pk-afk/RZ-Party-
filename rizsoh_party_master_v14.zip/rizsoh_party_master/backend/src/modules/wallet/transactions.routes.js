const router = require('express').Router();

router.get('/', async (req, res) => {
  res.json([
    { id: 't1', type: 'recharge', amount: 5000, currency: 'PKR', status: 'success' },
    { id: 't2', type: 'gift_spend', amount: 999, currency: 'coins', status: 'success' }
  ]);
});

module.exports = router;
