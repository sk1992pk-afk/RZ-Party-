const router = require('express').Router();
const User = require('../../models/User');
const GiftTransaction = require('../../models/GiftTransaction');
const WalletTransaction = require('../../models/WalletTransaction');
const { auth } = require('../../middleware/auth');

router.post('/send-advanced', auth, async (req, res) => {
  try {
    const { toUserId, targetType, targetId, giftId, qty = 1 } = req.body;
    const fromUser = await User.findById(req.user.id);
    const toUser = await User.findById(toUserId);
    if (!fromUser || !toUser) return res.status(404).json({ message: 'User not found' });

    const priceCoins = 99 * Number(qty || 1);
    if ((fromUser.wallet?.coins || 0) < priceCoins) {
      return res.status(400).json({ message: 'Insufficient coins' });
    }

    fromUser.wallet.coins -= priceCoins;
    toUser.wallet.diamonds += priceCoins;
    await fromUser.save();
    await toUser.save();

    const tx = await GiftTransaction.create({
      fromUserId: fromUser._id,
      toUserId: toUser._id,
      targetType,
      targetId,
      giftId,
      qty,
      priceCoins,
      diamondsAwarded: priceCoins
    });

    await WalletTransaction.create({
      userId: fromUser._id,
      type: 'gift_sent',
      amount: priceCoins,
      currency: 'coins',
      direction: 'debit',
      meta: { toUserId, giftId, targetType, targetId, qty }
    });

    await WalletTransaction.create({
      userId: toUser._id,
      type: 'gift_received',
      amount: priceCoins,
      currency: 'diamonds',
      direction: 'credit',
      meta: { fromUserId: fromUser._id.toString(), giftId, targetType, targetId, qty }
    });

    res.json({ message: 'gift sent', tx });
  } catch (e) {
    res.status(500).json({ message: 'gift send failed', error: e.message });
  }
});

module.exports = router;
