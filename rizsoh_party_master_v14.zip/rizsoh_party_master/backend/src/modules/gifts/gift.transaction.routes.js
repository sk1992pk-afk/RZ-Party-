const router = require('express').Router();
const { db } = require('../../db/inMemoryDb');
const { sendGift } = require('../../services/gift.service');

router.get('/transactions', async (req, res) => {
  res.json(db.giftTransactions);
});

router.post('/send-advanced', async (req, res) => {
  try {
    const tx = sendGift(req.body);
    res.json({ message: 'gift sent successfully', tx });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

module.exports = router;
