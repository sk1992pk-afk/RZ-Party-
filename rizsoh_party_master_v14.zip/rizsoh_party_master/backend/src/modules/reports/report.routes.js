const router = require('express').Router();
const Report = require('../../models/Report');
const { auth, adminOnly } = require('../../middleware/auth');

router.get('/', auth, async (req, res) => {
  const filter = req.user.role === 'admin' ? {} : { reporterUserId: req.user.id };
  const rows = await Report.find(filter).sort({ createdAt: -1 }).limit(200);
  res.json(rows);
});

router.post('/', auth, async (req, res) => {
  const row = await Report.create({
    reporterUserId: req.user.id,
    type: req.body.type || 'user',
    targetId: req.body.targetId || '',
    reason: req.body.reason || '',
  });
  res.json({ message: 'report submitted', report: row });
});

router.patch('/:id/review', auth, adminOnly, async (req, res) => {
  const row = await Report.findByIdAndUpdate(
    req.params.id,
    {
      status: req.body.status || 'reviewed',
      reviewNote: req.body.reviewNote || '',
      reviewedBy: req.user.id
    },
    { new: true }
  );
  res.json({ message: 'report reviewed', report: row });
});

module.exports = router;
