const router = require('express').Router();

router.get('/dashboard', async (req, res) => {
  res.json({
    stats: {
      users: 12345,
      activeRooms: 128,
      liveStreams: 42,
      pendingRecharges: 8,
      pendingWithdrawals: 5
    }
  });
});

router.get('/withdrawals', async (req, res) => {
  res.json([{ id: 'w1', user: 'Host 1', amount: 15000, status: 'pending' }]);
});

router.get('/recharges', async (req, res) => {
  res.json([{ id: 'r1', user: 'User 1', amount: 5000, method: 'JazzCash', status: 'pending' }]);
});

module.exports = router;
