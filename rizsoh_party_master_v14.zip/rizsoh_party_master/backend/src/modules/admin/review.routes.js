const router = require('express').Router();

router.get('/recharge-requests', async (req, res) => {
  res.json([{ id: 'rr1', user: 'User 9', amount: 1000, method: 'JazzCash', status: 'pending' }]);
});

router.get('/withdraw-requests', async (req, res) => {
  res.json([{ id: 'wr1', user: 'Host 5', amount: 20000, method: 'EasyPaisa', status: 'pending' }]);
});

module.exports = router;
