const router = require('express').Router();
const { auth } = require('../../middleware/auth');
const Message = require('../../models/Message');

router.get('/conversation/:conversationId', auth, async (req, res) => {
  const rows = await Message.find({ conversationId: req.params.conversationId }).sort({ createdAt: 1 }).limit(500);
  res.json(rows);
});

router.post('/conversation/:conversationId', auth, async (req, res) => {
  const row = await Message.create({
    conversationId: req.params.conversationId,
    fromUserId: req.user.id,
    toUserId: req.body.toUserId || null,
    roomId: req.body.roomId || null,
    liveId: req.body.liveId || null,
    body: req.body.body || '',
    type: req.body.type || 'text'
  });
  res.json({ message: 'message sent', messageRow: row });
});

module.exports = router;
