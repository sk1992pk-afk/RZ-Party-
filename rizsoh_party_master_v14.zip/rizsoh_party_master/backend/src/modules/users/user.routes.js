const router = require('express').Router();

router.get('/me', async (req, res) => {
  res.json({
    id: '1',
    name: 'Rizsoh User',
    bio: '',
    coins: 0,
    diamonds: 0
  });
});

module.exports = router;
