const router = require('express').Router();
const { createSettlement, listSettlements } = require('../../services/settlement.service');

router.get('/', async (req, res) => {
  res.json(listSettlements());
});

router.post('/', async (req, res) => {
  try {
    const row = createSettlement(req.body);
    res.json({ message: 'settlement created', row });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

module.exports = router;
