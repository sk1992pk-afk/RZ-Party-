const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../../models/User');

router.post('/register', async (req, res) => {
  try {
    const { name, phone, password } = req.body;
    if (!name || !phone || !password) return res.status(400).json({ message: 'name, phone, password required' });
    const exists = await User.findOne({ phone });
    if (exists) return res.status(409).json({ message: 'Phone already registered' });
    const passwordHash = await bcrypt.hash(password, 10);
    const user = await User.create({ name, phone, passwordHash });
    return res.json({ message: 'register success', user: { id: user._id, name: user.name, phone: user.phone } });
  } catch (e) {
    return res.status(500).json({ message: 'register failed', error: e.message });
  }
});

router.post('/login', async (req, res) => {
  try {
    const { phone, password } = req.body;
    const user = await User.findOne({ phone });
    if (!user) return res.status(404).json({ message: 'User not found' });
    const ok = await bcrypt.compare(password || '', user.passwordHash);
    if (!ok) return res.status(401).json({ message: 'Invalid credentials' });
    const token = jwt.sign(
      { id: user._id.toString(), role: user.role, phone: user.phone },
      process.env.JWT_SECRET || 'rizsoh_party_secret',
      { expiresIn: '30d' }
    );
    return res.json({
      message: 'login success',
      token,
      user: { id: user._id, name: user.name, phone: user.phone, role: user.role, wallet: user.wallet }
    });
  } catch (e) {
    return res.status(500).json({ message: 'login failed', error: e.message });
  }
});

module.exports = router;
