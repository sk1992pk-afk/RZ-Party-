const mongoose = require('mongoose');

async function connectDb() {
  const uri = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/rizsoh_party';
  await mongoose.connect(uri);
  console.log('Mongo connected');
}

module.exports = { connectDb };
