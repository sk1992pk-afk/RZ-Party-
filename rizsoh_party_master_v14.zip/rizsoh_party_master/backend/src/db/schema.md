# Rizsoh Party Data Model Foundation

## Core entities
- users
- rooms
- room_moderation_actions
- live_sessions
- families
- agencies
- gifts
- gift_transactions
- wallet_transactions
- recharge_requests
- withdraw_requests
- settlements
- push_tokens
- reports

## Suggested production tables
### users
- id
- phone / email
- password_hash
- name
- avatar
- bio
- gender
- country
- vip_level
- user_level
- coins
- diamonds
- earnings_pkr
- is_host
- family_id
- agency_id
- status
- created_at

### room_moderation_actions
- id
- room_id
- target_user_id
- action_type (mute / kick / ban / unban / seat_lock / seat_approve)
- reason
- action_by
- expires_at
- created_at

### settlements
- id
- agency_id
- host_user_id
- month_key
- gross_earnings
- agency_share
- host_share
- status
