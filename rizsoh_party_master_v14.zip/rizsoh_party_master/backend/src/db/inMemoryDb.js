const { v4: uuid } = require('uuid');

const db = {
  users: [
    {
      id: 'u1',
      name: 'Rizsoh User',
      vipLevel: 3,
      level: 12,
      coins: 12500,
      diamonds: 4220,
      earningsPkr: 32000,
      badges: ['vip3', 'lvl12']
    },
    {
      id: 'u2',
      name: 'Host Sara',
      vipLevel: 5,
      level: 22,
      coins: 9000,
      diamonds: 7000,
      earningsPkr: 85000,
      badges: ['vip5', 'host']
    }
  ],
  rooms: [
    { id: 'r1', name: 'Luxury Room 1', hostId: 'u2', locked: false, members: ['u1', 'u2'] }
  ],
  roomModeration: [],
  liveSessions: [],
  families: [
    { id: 'f1', name: 'Rizsoh Royals', leaderId: 'u2', members: ['u1', 'u2'], points: 2500 }
  ],
  agencies: [
    { id: 'a1', name: 'Rizsoh Elite Agency', ownerId: 'u2', hosts: ['u2'], monthlyIncome: 125000 }
  ],
  gifts: [
    { id: 'g1', name: 'Rose', priceCoins: 99, category: 'basic' },
    { id: 'g2', name: 'Crown', priceCoins: 999, category: 'premium' },
    { id: 'g3', name: 'Castle', priceCoins: 4999, category: 'luxury' }
  ],
  giftTransactions: [],
  walletTransactions: [],
  rechargeRequests: [],
  withdrawRequests: [],
  settlements: [],
  pushTokens: [],
  reports: []
};

function makeId(prefix) {
  return `${prefix}_${uuid().slice(0, 8)}`;
}

module.exports = { db, makeId };
