const mongoose = require('mongoose');

const roomSchema = new mongoose.Schema({
  title: { type: String, required: true },
  cover: { type: String, default: '' },
  ownerUserId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  type: { type: String, enum: ['voice','party','karaoke'], default: 'voice' },
  language: { type: String, default: 'en' },
  seats: { type: Number, default: 8 },
  isLocked: { type: Boolean, default: false }
}, { timestamps: true });

module.exports = mongoose.model('Room', roomSchema);
