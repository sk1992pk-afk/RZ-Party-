const mongoose = require('mongoose');

const familyMemberSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  role: { type: String, enum: ['owner','co_owner','member'], default: 'member' },
  joinedAt: { type: Date, default: Date.now }
}, { _id: false });

const familySchema = new mongoose.Schema({
  name: { type: String, required: true },
  bio: { type: String, default: '' },
  logo: { type: String, default: '' },
  ownerUserId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  members: { type: [familyMemberSchema], default: [] },
  level: { type: Number, default: 1 }
}, { timestamps: true });

module.exports = mongoose.model('Family', familySchema);
