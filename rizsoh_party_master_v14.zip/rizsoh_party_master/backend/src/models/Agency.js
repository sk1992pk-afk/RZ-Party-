const mongoose = require('mongoose');

const agencyHostSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  joinedAt: { type: Date, default: Date.now },
  status: { type: String, enum: ['active','inactive'], default: 'active' }
}, { _id: false });

const agencySchema = new mongoose.Schema({
  name: { type: String, required: true },
  code: { type: String, unique: true, required: true },
  ownerUserId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  hosts: { type: [agencyHostSchema], default: [] },
  commissionRate: { type: Number, default: 20 }
}, { timestamps: true });

module.exports = mongoose.model('Agency', agencySchema);
