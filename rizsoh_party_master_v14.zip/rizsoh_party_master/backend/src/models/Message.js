const mongoose = require('mongoose');

const messageSchema = new mongoose.Schema({
  conversationId: { type: String, required: true },
  fromUserId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  toUserId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  roomId: { type: mongoose.Schema.Types.ObjectId, ref: 'Room' },
  liveId: { type: mongoose.Schema.Types.ObjectId, ref: 'LiveSession' },
  body: { type: String, default: '' },
  type: { type: String, enum: ['text','gift_notice','system'], default: 'text' }
}, { timestamps: true });

module.exports = mongoose.model('Message', messageSchema);
