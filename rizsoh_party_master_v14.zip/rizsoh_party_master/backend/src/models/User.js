const mongoose = require('mongoose');

const walletSchema = new mongoose.Schema({
  coins: { type: Number, default: 0 },
  diamonds: { type: Number, default: 0 },
  earnings: { type: Number, default: 0 },
}, { _id: false });

const userSchema = new mongoose.Schema({
  name: String,
  phone: { type: String, unique: true, sparse: true },
  email: { type: String, unique: true, sparse: true },
  passwordHash: { type: String, required: true },
  avatar: String,
  country: String,
  language: { type: String, default: 'en' },
  vipLevel: { type: Number, default: 0 },
  wallet: { type: walletSchema, default: () => ({}) },
  role: { type: String, enum: ['user','admin','host','agent'], default: 'user' }
}, { timestamps: true });

module.exports = mongoose.model('User', userSchema);
