const mongoose = require('mongoose');

const withdrawRequestSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  amount: { type: Number, required: true },
  method: { type: String, enum: ['JazzCash','EasyPaisa','Bank'], default: 'JazzCash' },
  accountTitle: String,
  accountNumber: String,
  status: { type: String, enum: ['pending','approved','rejected','paid'], default: 'pending' },
  reviewNote: String,
  reviewedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
}, { timestamps: true });

module.exports = mongoose.model('WithdrawRequest', withdrawRequestSchema);
