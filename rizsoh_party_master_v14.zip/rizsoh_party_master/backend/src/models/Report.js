const mongoose = require('mongoose');

const reportSchema = new mongoose.Schema({
  reporterUserId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  type: String,
  targetId: String,
  reason: String,
  status: { type: String, enum: ['pending','reviewed','resolved','rejected'], default: 'pending' },
  reviewNote: String,
  reviewedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
}, { timestamps: true });

module.exports = mongoose.model('Report', reportSchema);
