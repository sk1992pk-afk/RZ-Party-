const mongoose = require('mongoose');

const rechargeRequestSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  amount: { type: Number, required: true },
  method: { type: String, enum: ['JazzCash','EasyPaisa','Manual'], default: 'JazzCash' },
  senderAccount: String,
  transactionId: String,
  proofImage: String,
  status: { type: String, enum: ['pending','approved','rejected'], default: 'pending' },
  reviewNote: String,
  reviewedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
}, { timestamps: true });

module.exports = mongoose.model('RechargeRequest', rechargeRequestSchema);
