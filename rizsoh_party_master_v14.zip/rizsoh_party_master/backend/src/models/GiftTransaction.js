const mongoose = require('mongoose');

const giftTransactionSchema = new mongoose.Schema({
  fromUserId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  toUserId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  targetType: String,
  targetId: String,
  giftId: String,
  qty: { type: Number, default: 1 },
  priceCoins: { type: Number, default: 0 },
  diamondsAwarded: { type: Number, default: 0 }
}, { timestamps: true });

module.exports = mongoose.model('GiftTransaction', giftTransactionSchema);
