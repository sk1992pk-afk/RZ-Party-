const mongoose = require('mongoose');

const liveSessionSchema = new mongoose.Schema({
  hostUserId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  title: { type: String, required: true },
  cover: { type: String, default: '' },
  status: { type: String, enum: ['live','ended'], default: 'live' },
  viewers: { type: Number, default: 0 }
}, { timestamps: true });

module.exports = mongoose.model('LiveSession', liveSessionSchema);
