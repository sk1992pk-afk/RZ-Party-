const mongoose = require('mongoose');

const walletTransactionSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  type: String,
  amount: Number,
  currency: { type: String, enum: ['coins','diamonds','pkr'], default: 'coins' },
  direction: { type: String, enum: ['credit','debit'], default: 'debit' },
  meta: { type: Object, default: {} }
}, { timestamps: true });

module.exports = mongoose.model('WalletTransaction', walletTransactionSchema);
