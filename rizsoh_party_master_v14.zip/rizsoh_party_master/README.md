# Rizsoh Party Master v14

## Block 9 added
- RTC token scaffold endpoints for room/live
- Flutter RTC API service
- Media engine service placeholder for Agora/Zego integration
- Polished room seat UI scaffold
- Polished live video UI scaffold
- Inbox list screen
- Family detail screen
- Agency detail screen
- Social hub home screen
- backend .env.example for release prep

## Next release tasks
1. Replace MediaEngineService with Agora or Zego SDK implementation.
2. Add Android INTERNET / RECORD_AUDIO / CAMERA permissions.
3. Add Firebase config and push notification wiring.
4. Configure signing configs and release keystore.
5. Replace demo RTC token endpoints with secure server-side token generation.
