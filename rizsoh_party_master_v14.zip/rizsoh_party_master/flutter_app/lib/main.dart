import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'src/core/network/api_client.dart';
import 'src/core/storage/session_storage.dart';
import 'src/features/app/app_state.dart';
import 'src/features/auth/auth_provider.dart';
import 'src/features/reports/report_provider.dart';
import 'src/features/rooms/gift_provider.dart';
import 'src/features/wallet/wallet_provider.dart';
import 'src/screens/home/home_shell_screen.dart';
import 'src/screens/auth/login_screen.dart';
import 'src/services/gift_api_service.dart';
import 'src/services/auth_api_service.dart';
import 'src/services/report_api_service.dart';
import 'src/services/wallet_api_service.dart';

void main() {
  final api = ApiClient(baseUrl: 'http://10.0.2.2:4000');
  final storage = SessionStorage();

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AppState(storage)..bootstrap()),
        ChangeNotifierProxyProvider<AppState, AuthProvider>(
          create: (context) => AuthProvider(AuthApiService(api), context.read<AppState>()),
          update: (_, appState, previous) => AuthProvider(AuthApiService(api), appState),
        ),
        ChangeNotifierProvider(create: (_) => WalletProvider(WalletApiService(api))),
        ChangeNotifierProvider(create: (_) => GiftProvider(GiftApiService(api))),
        ChangeNotifierProvider(create: (_) => ReportProvider(ReportApiService(api))),
      ],
      child: const RizsohPartyApp(),
    ),
  );
}

class RizsohPartyApp extends StatelessWidget {
  const RizsohPartyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Rizsoh Party',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorSchemeSeed: const Color(0xFFE91E63),
        useMaterial3: true,
      ),
      home: Consumer<AppState>(
        builder: (_, app, __) {
          if (!app.initialized) {
            return const Scaffold(body: Center(child: CircularProgressIndicator()));
          }
          return app.loggedIn ? const HomeShellScreen() : const LoginScreen();
        },
      ),
    );
  }
}
