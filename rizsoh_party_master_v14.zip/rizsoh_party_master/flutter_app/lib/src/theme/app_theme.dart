import 'package:flutter/material.dart';

class AppTheme {
  static const Color pink = Color(0xFFFF4FA3);
  static const Color gold = Color(0xFFFFD166);
  static const Color softWhite = Color(0xFFFFFBFE);

  static ThemeData light() {
    return ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: softWhite,
      colorScheme: ColorScheme.fromSeed(
        seedColor: pink,
        primary: pink,
        secondary: gold,
        surface: Colors.white,
      ),
      appBarTheme: const AppBarTheme(
        centerTitle: true,
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide.none,
        ),
      ),
    );
  }
}
