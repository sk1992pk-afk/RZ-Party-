import 'package:flutter/material.dart';

class AgencyCenterScreen extends StatelessWidget {
  const AgencyCenterScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final items = const [
      'My hosts',
      'Pending host applications',
      'Settlement history',
      'Monthly agency income',
      'Agency profile & manager',
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('Agency Center')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: items.map((e) => Card(child: ListTile(title: Text(e), trailing: const Icon(Icons.chevron_right)))).toList(),
      ),
    );
  }
}
