import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../features/app/app_state.dart';
import '../../features/rooms/gift_provider.dart';
import '../../widgets/gifts/gift_bottom_sheet.dart';
import '../safety/report_submit_screen.dart';

class LiveRoomScreen extends StatefulWidget {
  const LiveRoomScreen({super.key});

  @override
  State<LiveRoomScreen> createState() => _LiveRoomScreenState();
}

class _LiveRoomScreenState extends State<LiveRoomScreen> {
  final comments = <String>['Welcome to Rizsoh live'];
  final controller = TextEditingController();

  void _openGiftSheet() {
    showModalBottomSheet(
      context: context,
      builder: (_) => GiftBottomSheet(
        onSelected: (gift) async {
          final userId = context.read<AppState>().userId ?? 'u1';
          final ok = await context.read<GiftProvider>().sendGift(
            fromUserId: userId,
            toUserId: 'u2',
            targetType: 'live',
            targetId: 'live_1',
            giftId: gift['id'] ?? 'g1',
            qty: 1,
          );
          if (!mounted) return;
          final message = context.read<GiftProvider>().lastMessage ?? (ok ? 'Gift sent' : 'Gift failed');
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final giftProvider = context.watch<GiftProvider>();
    return Scaffold(
      appBar: AppBar(
        title: const Text('Live Room'),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const ReportSubmitScreen(targetId: 'live_1', type: 'live'),
                ),
              );
            },
            icon: const Icon(Icons.report_gmailerrorred),
          )
        ],
      ),
      body: Stack(
        children: [
          Container(color: const Color(0xFFFDF1F6)),
          Positioned(
            left: 12, right: 12, bottom: 80, top: 12,
            child: ListView(
              children: comments.map((e) => Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Text(e),
              )).toList(),
            ),
          ),
          Positioned(
            left: 12, right: 12, bottom: 12,
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: controller,
                    decoration: const InputDecoration(
                      hintText: 'Write comment',
                      filled: true,
                    ),
                    onSubmitted: (v) {
                      if (v.trim().isEmpty) return;
                      setState(() => comments.add(v.trim()));
                      controller.clear();
                    },
                  ),
                ),
                if (giftProvider.sending)
                  const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 8),
                    child: SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)),
                  ),
                IconButton(onPressed: _openGiftSheet, icon: const Icon(Icons.card_giftcard)),
              ],
            ),
          )
        ],
      ),
    );
  }
}
