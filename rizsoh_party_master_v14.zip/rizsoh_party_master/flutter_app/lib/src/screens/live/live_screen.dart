import 'package:flutter/material.dart';

class LiveScreen extends StatelessWidget {
  const LiveScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Live Streaming')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: List.generate(8, (i) => Card(
          child: ListTile(
            leading: const CircleAvatar(child: Icon(Icons.live_tv)),
            title: Text('Live Host ${i + 1}'),
            subtitle: const Text('Tap to watch live stream'),
            trailing: const Icon(Icons.play_circle_fill),
          ),
        )),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {},
        label: const Text('Go Live'),
        icon: const Icon(Icons.videocam),
      ),
    );
  }
}
