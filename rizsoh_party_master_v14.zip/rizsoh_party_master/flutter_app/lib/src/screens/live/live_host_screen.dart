import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../features/app/app_state.dart';
import '../../services/realtime_service.dart';
import '../../services/rtc_api_service.dart';
import '../../services/media_engine_service.dart';
import '../../core/network/api_client.dart';

class LiveHostScreen extends StatefulWidget {
  final String liveId;
  final String title;
  const LiveHostScreen({super.key, required this.liveId, required this.title});

  @override
  State<LiveHostScreen> createState() => _LiveHostScreenState();
}

class _LiveHostScreenState extends State<LiveHostScreen> {
  final rt = RealtimeService();
  final media = MediaEngineService();
  final comment = TextEditingController();
  final List<String> feed = [];
  bool engineReady = false;

  @override
  void initState() {
    super.initState();
    Future.microtask(_boot);
  }

  Future<void> _boot() async {
    final appState = context.read<AppState>();
    final userId = appState.userId ?? 'guest';
    final api = RtcApiService(ApiClient(baseUrl: 'http://10.0.2.2:4000', token: appState.token));
    final rtc = await api.getLiveToken(liveId: widget.liveId, uid: userId, role: 'host');
    await media.initLive(
      provider: rtc['provider'].toString(),
      appId: rtc['appId'].toString(),
      token: rtc['token'].toString(),
      channelId: widget.liveId,
      uid: userId,
      isHost: true,
    );
    rt.connect('http://10.0.2.2:4000');
    rt.joinLive(widget.liveId, userId);
    rt.on('live_viewer_joined', (d) => setState(() => feed.add('Viewer joined: ${d['userId']}')));
    rt.on('live_comment', (d) => setState(() => feed.add(d['comment']['body'].toString())));
    rt.on('live_gift', (d) => setState(() => feed.add('Live gift: ${d['gift']['giftId']} x${d['gift']['qty']}')));
    if (mounted) setState(() => engineReady = true);
  }

  @override
  void dispose() {
    rt.leaveLive(widget.liveId, context.read<AppState>().userId ?? 'guest');
    rt.dispose();
    media.leave();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final userId = context.read<AppState>().userId ?? 'guest';
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: Stack(
        children: [
          Container(
            color: Colors.black12,
            alignment: Alignment.center,
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              const Icon(Icons.videocam, size: 72),
              const SizedBox(height: 12),
              Text(engineReady ? 'Live video engine scaffold ready' : 'Preparing live stream...'),
            ]),
          ),
          Positioned(
            top: 12, left: 12, right: 12,
            child: Row(
              children: [
                Chip(label: Text('LIVE • ${widget.liveId.substring(0, widget.liveId.length.clamp(0, 6))}')),
                const Spacer(),
                const CircleAvatar(child: Icon(Icons.person)),
              ],
            ),
          ),
          Positioned(
            right: 8, top: 80, bottom: 150,
            child: SizedBox(
              width: 180,
              child: Card(
                child: ListView.builder(
                  itemCount: feed.length,
                  itemBuilder: (_, i) => Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(feed[i], style: const TextStyle(fontSize: 12)),
                  ),
                ),
              ),
            ),
          ),
          Positioned(
            left: 8, right: 8, bottom: 8,
            child: Column(
              children: [
                Row(
                  children: [
                    Expanded(child: TextField(controller: comment, decoration: const InputDecoration(fillColor: Colors.white, filled: true, hintText: 'Say something...'))),
                    IconButton(
                      onPressed: () {
                        rt.sendLiveComment(widget.liveId, {'body': comment.text.trim(), 'fromUserId': userId});
                        comment.clear();
                      },
                      icon: const Icon(Icons.send),
                    ),
                    ElevatedButton(
                      onPressed: () => rt.sendLiveGift(widget.liveId, {'giftId': 'car', 'qty': 1, 'from': userId}),
                      child: const Text('Gift'),
                    )
                  ],
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}
