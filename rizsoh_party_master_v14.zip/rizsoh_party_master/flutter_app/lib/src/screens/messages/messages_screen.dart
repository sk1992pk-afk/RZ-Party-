import 'package:flutter/material.dart';
import 'chat_thread_screen.dart';

class MessagesScreen extends StatelessWidget {
  const MessagesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Messages')),
      body: ListView.builder(
        itemCount: 12,
        itemBuilder: (_, i) => ListTile(
          leading: const CircleAvatar(child: Icon(Icons.person)),
          title: Text('User ${i + 1}'),
          subtitle: const Text('Last message preview...'),
          trailing: const Text('2m'),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ChatThreadScreen(username: 'User ${i+1}'))),
        ),
      ),
    );
  }
}
