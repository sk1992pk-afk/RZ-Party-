import 'package:flutter/material.dart';

class ChatThreadScreen extends StatefulWidget {
  final String username;
  const ChatThreadScreen({super.key, required this.username});

  @override
  State<ChatThreadScreen> createState() => _ChatThreadScreenState();
}

class _ChatThreadScreenState extends State<ChatThreadScreen> {
  final controller = TextEditingController();
  final messages = <Map<String, String>>[
    {'from': 'them', 'text': 'Hello 👋'},
    {'from': 'me', 'text': 'Welcome to Rizsoh Party'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.username)),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: messages.length,
              itemBuilder: (_, i) {
                final m = messages[i];
                final me = m['from'] == 'me';
                return Align(
                  alignment: me ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    margin: const EdgeInsets.symmetric(vertical: 4),
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      color: me ? const Color(0xFFFF4FA3) : Colors.white,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Text(m['text']!, style: TextStyle(color: me ? Colors.white : Colors.black)),
                  ),
                );
              },
            ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  Expanded(child: TextField(controller: controller, decoration: const InputDecoration(hintText: 'Type a message'))),
                  const SizedBox(width: 8),
                  FilledButton(
                    onPressed: () {
                      if (controller.text.trim().isEmpty) return;
                      setState(() => messages.add({'from': 'me', 'text': controller.text.trim()}));
                      controller.clear();
                    },
                    child: const Text('Send'),
                  )
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}
