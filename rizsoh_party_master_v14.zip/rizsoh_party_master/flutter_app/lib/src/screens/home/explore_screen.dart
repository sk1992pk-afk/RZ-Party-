import 'package:flutter/material.dart';

class ExploreScreen extends StatelessWidget {
  const ExploreScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final cards = [
      'Trending Rooms',
      'Popular Hosts',
      'New Families',
      'Top Agencies',
    ];

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('Explore', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        ...cards.map((e) => Card(
          child: ListTile(
            title: Text(e),
            subtitle: const Text('Rizsoh Party discovery section'),
            trailing: const Icon(Icons.chevron_right),
          ),
        ))
      ],
    );
  }
}
