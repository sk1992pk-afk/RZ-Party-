import 'package:flutter/material.dart';
import '../social/family_list_screen.dart';
import '../social/agency_list_screen.dart';
import '../social/room_list_screen.dart';
import '../social/live_list_screen.dart';
import '../chat/inbox_list_screen.dart';

class SocialHubScreen extends StatelessWidget {
  const SocialHubScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final items = <Map<String, dynamic>>[
      {'title': 'Voice Rooms', 'icon': Icons.mic, 'page': const RoomListScreen()},
      {'title': 'Live', 'icon': Icons.live_tv, 'page': const LiveListScreen()},
      {'title': 'Inbox', 'icon': Icons.chat_bubble, 'page': const InboxListScreen()},
      {'title': 'Families', 'icon': Icons.groups, 'page': const FamilyListScreen()},
      {'title': 'Agencies', 'icon': Icons.business_center, 'page': const AgencyListScreen()},
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('Rizsoh Party')),
      body: GridView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: items.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: 1.15, crossAxisSpacing: 12, mainAxisSpacing: 12),
        itemBuilder: (_, i) {
          final item = items[i];
          return InkWell(
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => item['page'] as Widget)),
            child: Card(
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(item['icon'] as IconData, size: 42),
                const SizedBox(height: 12),
                Text(item['title'].toString()),
              ]),
            ),
          );
        },
      ),
    );
  }
}
