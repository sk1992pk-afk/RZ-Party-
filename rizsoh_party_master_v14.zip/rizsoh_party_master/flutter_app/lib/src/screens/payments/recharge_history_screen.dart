import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../features/app/app_state.dart';
import '../../services/payment_api_service.dart';
import '../../core/network/api_client.dart';
import 'recharge_request_screen.dart';
import 'withdraw_request_screen.dart';

class RechargeHistoryScreen extends StatefulWidget {
  const RechargeHistoryScreen({super.key});

  @override
  State<RechargeHistoryScreen> createState() => _RechargeHistoryScreenState();
}

class _RechargeHistoryScreenState extends State<RechargeHistoryScreen> {
  bool loading = true;
  List<dynamic> recharges = [];
  List<dynamic> withdraws = [];

  @override
  void initState() {
    super.initState();
    Future.microtask(_load);
  }

  Future<void> _load() async {
    final token = context.read<AppState>().token ?? '';
    final api = PaymentApiService(ApiClient(baseUrl: 'http://10.0.2.2:4000', token: token));
    try {
      recharges = await api.getMyRecharges();
      withdraws = await api.getMyWithdraws();
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Recharge & Withdraw')),
      floatingActionButton: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          FloatingActionButton.extended(
            heroTag: 'recharge',
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RechargeRequestScreen())),
            label: const Text('Recharge'),
            icon: const Icon(Icons.add_card),
          ),
          const SizedBox(height: 10),
          FloatingActionButton.extended(
            heroTag: 'withdraw',
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const WithdrawRequestScreen())),
            label: const Text('Withdraw'),
            icon: const Icon(Icons.money_off),
          ),
        ],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(12),
              children: [
                const Text('Recharge Requests', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                ...recharges.map((r) {
                  final row = r as Map<String, dynamic>;
                  return Card(
                    child: ListTile(
                      title: Text('${row['amount']} • ${row['method']}'),
                      subtitle: Text(row['transactionId']?.toString() ?? ''),
                      trailing: Text(row['status']?.toString() ?? ''),
                    ),
                  );
                }),
                const SizedBox(height: 20),
                const Text('Withdraw Requests', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                ...withdraws.map((r) {
                  final row = r as Map<String, dynamic>;
                  return Card(
                    child: ListTile(
                      title: Text('${row['amount']} • ${row['method']}'),
                      subtitle: Text(row['accountNumber']?.toString() ?? ''),
                      trailing: Text(row['status']?.toString() ?? ''),
                    ),
                  );
                }),
              ],
            ),
    );
  }
}
