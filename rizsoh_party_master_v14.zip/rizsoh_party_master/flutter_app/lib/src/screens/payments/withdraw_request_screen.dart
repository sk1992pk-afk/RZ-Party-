import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/network/api_client.dart';
import '../../features/app/app_state.dart';
import '../../services/payment_api_service.dart';

class WithdrawRequestScreen extends StatefulWidget {
  const WithdrawRequestScreen({super.key});

  @override
  State<WithdrawRequestScreen> createState() => _WithdrawRequestScreenState();
}

class _WithdrawRequestScreenState extends State<WithdrawRequestScreen> {
  final amount = TextEditingController();
  final title = TextEditingController();
  final account = TextEditingController();
  String method = 'JazzCash';
  bool loading = false;

  @override
  Widget build(BuildContext context) {
    final token = context.read<AppState>().token ?? '';
    final api = PaymentApiService(ApiClient(baseUrl: 'http://10.0.2.2:4000', token: token));
    return Scaffold(
      appBar: AppBar(title: const Text('Withdraw Request')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          DropdownButtonFormField<String>(
            value: method,
            items: const ['JazzCash', 'EasyPaisa', 'Bank']
                .map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
            onChanged: (v) => setState(() => method = v ?? 'JazzCash'),
          ),
          const SizedBox(height: 12),
          TextField(controller: amount, decoration: const InputDecoration(labelText: 'Amount')),
          const SizedBox(height: 12),
          TextField(controller: title, decoration: const InputDecoration(labelText: 'Account title')),
          const SizedBox(height: 12),
          TextField(controller: account, decoration: const InputDecoration(labelText: 'Account number')),
          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: loading ? null : () async {
              setState(() => loading = true);
              try {
                final res = await api.submitWithdraw(
                  amount: int.tryParse(amount.text.trim()) ?? 0,
                  method: method,
                  accountTitle: title.text.trim(),
                  accountNumber: account.text.trim(),
                );
                if (!mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text(res['message']?.toString() ?? 'Withdraw request sent')),
                );
                Navigator.pop(context);
              } finally {
                if (mounted) setState(() => loading = false);
              }
            },
            child: Text(loading ? 'Submitting...' : 'Submit request'),
          )
        ],
      ),
    );
  }
}
