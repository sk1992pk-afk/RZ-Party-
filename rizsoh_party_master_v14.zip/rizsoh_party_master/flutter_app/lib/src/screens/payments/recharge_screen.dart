import 'package:flutter/material.dart';

class RechargeScreen extends StatelessWidget {
  const RechargeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final packs = const [500, 1000, 5000, 10000];
    return Scaffold(
      appBar: AppBar(title: const Text('Recharge Coins')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Select package', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          ...packs.map((p) => Card(child: ListTile(
            title: Text('$p PKR'),
            subtitle: Text('${p * 2} coins'),
            trailing: const Text('JazzCash / EasyPaisa'),
          ))),
          const SizedBox(height: 20),
          const Text('Manual Payment Details'),
          const SizedBox(height: 8),
          const TextField(decoration: InputDecoration(labelText: 'Sender account / phone')),
          const SizedBox(height: 8),
          const TextField(decoration: InputDecoration(labelText: 'Transaction ID')),
          const SizedBox(height: 12),
          FilledButton(onPressed: () {}, child: const Text('Submit Recharge Request'))
        ],
      ),
    );
  }
}
