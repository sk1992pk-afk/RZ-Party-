import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/network/api_client.dart';
import '../../features/app/app_state.dart';
import '../../services/social_api_service.dart';
import '../rooms/room_live_screen.dart';

class RoomListScreen extends StatefulWidget {
  const RoomListScreen({super.key});
  @override
  State<RoomListScreen> createState() => _RoomListScreenState();
}

class _RoomListScreenState extends State<RoomListScreen> {
  bool loading = true;
  List<dynamic> rows = [];
  @override
  void initState() { super.initState(); Future.microtask(_load); }

  Future<void> _load() async {
    final api = SocialApiService(ApiClient(baseUrl: 'http://10.0.2.2:4000', token: context.read<AppState>().token));
    rows = await api.getRooms();
    if (mounted) setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    final api = SocialApiService(ApiClient(baseUrl: 'http://10.0.2.2:4000', token: context.read<AppState>().token));
    return Scaffold(
      appBar: AppBar(title: const Text('Voice Rooms')),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          await api.createRoom('My Voice Room');
          if (mounted) { setState(() => loading = true); await _load(); }
        },
        child: const Icon(Icons.mic),
      ),
      body: loading ? const Center(child: CircularProgressIndicator()) : ListView.builder(
        itemCount: rows.length,
        itemBuilder: (_, i) {
          final r = rows[i] as Map<String, dynamic>;
          return ListTile(
            title: Text(r['title']?.toString() ?? 'Room'),
            subtitle: Text(r['type']?.toString() ?? 'voice'),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => RoomLiveScreen(roomId: r['_id'].toString(), roomTitle: r['title']?.toString() ?? 'Room'))),
          );
        },
      ),
    );
  }
}
