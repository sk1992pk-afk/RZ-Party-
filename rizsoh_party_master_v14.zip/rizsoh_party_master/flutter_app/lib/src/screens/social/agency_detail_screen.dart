import 'package:flutter/material.dart';

class AgencyDetailScreen extends StatelessWidget {
  final Map<String, dynamic> agency;
  const AgencyDetailScreen({super.key, required this.agency});

  @override
  Widget build(BuildContext context) {
    final hosts = (agency['hosts'] as List?) ?? [];
    return Scaffold(
      appBar: AppBar(title: Text(agency['name']?.toString() ?? 'Agency')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          CircleAvatar(radius: 34, child: Text((agency['name']?.toString() ?? 'A').substring(0,1))),
          const SizedBox(height: 12),
          Text('Code: ${agency['code'] ?? ''}'),
          const SizedBox(height: 16),
          Text('Hosts (${hosts.length})', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          ...hosts.map((m) => ListTile(
            leading: const CircleAvatar(child: Icon(Icons.mic)),
            title: Text(m['userId']?.toString() ?? 'Host'),
            subtitle: Text(m['status']?.toString() ?? 'active'),
          )),
        ],
      ),
    );
  }
}
