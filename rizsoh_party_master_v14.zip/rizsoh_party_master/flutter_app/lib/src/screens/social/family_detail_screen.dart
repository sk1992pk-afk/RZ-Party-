import 'package:flutter/material.dart';

class FamilyDetailScreen extends StatelessWidget {
  final Map<String, dynamic> family;
  const FamilyDetailScreen({super.key, required this.family});

  @override
  Widget build(BuildContext context) {
    final members = (family['members'] as List?) ?? [];
    return Scaffold(
      appBar: AppBar(title: Text(family['name']?.toString() ?? 'Family')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          CircleAvatar(radius: 34, child: Text((family['name']?.toString() ?? 'F').substring(0,1))),
          const SizedBox(height: 12),
          Text(family['bio']?.toString() ?? '', style: Theme.of(context).textTheme.bodyMedium),
          const SizedBox(height: 16),
          Text('Members (${members.length})', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          ...members.map((m) => ListTile(
            leading: const CircleAvatar(child: Icon(Icons.person)),
            title: Text(m['userId']?.toString() ?? 'Member'),
            subtitle: Text(m['role']?.toString() ?? 'member'),
          )),
        ],
      ),
    );
  }
}
