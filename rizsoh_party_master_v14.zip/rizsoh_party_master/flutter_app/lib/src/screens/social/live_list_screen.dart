import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/network/api_client.dart';
import '../../features/app/app_state.dart';
import '../../services/social_api_service.dart';
import '../live/live_host_screen.dart';

class LiveListScreen extends StatefulWidget {
  const LiveListScreen({super.key});
  @override
  State<LiveListScreen> createState() => _LiveListScreenState();
}

class _LiveListScreenState extends State<LiveListScreen> {
  bool loading = true;
  List<dynamic> rows = [];
  @override
  void initState() { super.initState(); Future.microtask(_load); }

  Future<void> _load() async {
    final api = SocialApiService(ApiClient(baseUrl: 'http://10.0.2.2:4000', token: context.read<AppState>().token));
    rows = await api.getLives();
    if (mounted) setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    final api = SocialApiService(ApiClient(baseUrl: 'http://10.0.2.2:4000', token: context.read<AppState>().token));
    return Scaffold(
      appBar: AppBar(title: const Text('Live Sessions')),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final res = await api.startLive('My Live');
          final live = res['live'] as Map<String, dynamic>;
          if (!mounted) return;
          Navigator.push(context, MaterialPageRoute(builder: (_) => LiveHostScreen(liveId: live['_id'].toString(), title: live['title']?.toString() ?? 'Live')));
        },
        child: const Icon(Icons.live_tv),
      ),
      body: loading ? const Center(child: CircularProgressIndicator()) : ListView.builder(
        itemCount: rows.length,
        itemBuilder: (_, i) {
          final r = rows[i] as Map<String, dynamic>;
          return ListTile(
            title: Text(r['title']?.toString() ?? 'Live'),
            subtitle: Text(r['status']?.toString() ?? 'live'),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => LiveHostScreen(liveId: r['_id'].toString(), title: r['title']?.toString() ?? 'Live'))),
          );
        },
      ),
    );
  }
}
