import 'package:flutter/material.dart';

class GiftMallScreen extends StatelessWidget {
  const GiftMallScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final gifts = [
      {'name':'Rose','price':'99'},
      {'name':'Crown','price':'999'},
      {'name':'Castle','price':'4999'},
      {'name':'Luxury Car','price':'9999'},
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('Gift Mall')),
      body: GridView.builder(
        padding: const EdgeInsets.all(16),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: 1.15, crossAxisSpacing: 12, mainAxisSpacing: 12),
        itemCount: gifts.length,
        itemBuilder: (_, i) {
          final g = gifts[i];
          return Card(
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              const Icon(Icons.card_giftcard, size: 42),
              const SizedBox(height: 10),
              Text(g['name']!),
              const SizedBox(height: 6),
              Text('${g['price']} coins'),
            ]),
          );
        },
      ),
    );
  }
}
