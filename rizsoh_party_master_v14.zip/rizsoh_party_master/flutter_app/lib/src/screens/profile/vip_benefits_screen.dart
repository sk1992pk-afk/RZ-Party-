import 'package:flutter/material.dart';

class VipBenefitsScreen extends StatelessWidget {
  const VipBenefitsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final benefits = const [
      'VIP badge & profile frame',
      'Priority room seat',
      'Room highlight',
      'Exclusive gift access',
      'Seasonal profile decoration',
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('VIP Benefits')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: benefits.map((e) => Card(child: ListTile(title: Text(e)))).toList(),
      ),
    );
  }
}
