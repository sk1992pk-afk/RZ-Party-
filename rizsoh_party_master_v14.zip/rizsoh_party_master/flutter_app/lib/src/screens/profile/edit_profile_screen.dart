import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/network/api_client.dart';
import '../../features/app/app_state.dart';
import '../../services/profile_api_service.dart';

class EditProfileScreen extends StatefulWidget {
  const EditProfileScreen({super.key});

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  final name = TextEditingController();
  final country = TextEditingController();
  final avatar = TextEditingController();
  bool loading = true;
  bool saving = false;

  @override
  void initState() {
    super.initState();
    Future.microtask(_load);
  }

  Future<void> _load() async {
    final token = context.read<AppState>().token ?? '';
    final api = ProfileApiService(ApiClient(baseUrl: 'http://10.0.2.2:4000', token: token));
    final me = await api.getMe();
    name.text = me['name']?.toString() ?? '';
    country.text = me['country']?.toString() ?? '';
    avatar.text = me['avatar']?.toString() ?? '';
    if (mounted) setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    final token = context.read<AppState>().token ?? '';
    final api = ProfileApiService(ApiClient(baseUrl: 'http://10.0.2.2:4000', token: token));
    return Scaffold(
      appBar: AppBar(title: const Text('Edit Profile')),
      body: loading ? const Center(child: CircularProgressIndicator()) : ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(controller: name, decoration: const InputDecoration(labelText: 'Name')),
          const SizedBox(height: 12),
          TextField(controller: country, decoration: const InputDecoration(labelText: 'Country')),
          const SizedBox(height: 12),
          TextField(controller: avatar, decoration: const InputDecoration(labelText: 'Avatar URL')),
          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: saving ? null : () async {
              setState(() => saving = true);
              try {
                await api.updateMe({
                  'name': name.text.trim(),
                  'country': country.text.trim(),
                  'avatar': avatar.text.trim(),
                });
                if (!mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Profile updated')));
              } finally {
                if (mounted) setState(() => saving = false);
              }
            },
            child: Text(saving ? 'Saving...' : 'Save'),
          )
        ],
      ),
    );
  }
}
