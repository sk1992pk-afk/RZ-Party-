import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../features/app/app_state.dart';
import '../profile/vip_benefits_screen.dart';
import '../safety/report_center_screen.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(title: const Text('My Profile')),
      body: ListView(
        children: [
          ListTile(title: const Text('User ID'), subtitle: Text(app.userId ?? 'Guest')),
          ListTile(
            title: const Text('VIP Benefits'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const VipBenefitsScreen())),
          ),
          ListTile(
            title: const Text('Safety Reports'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ReportCenterScreen())),
          ),
          ListTile(
            title: const Text('Logout'),
            trailing: const Icon(Icons.logout),
            onTap: () => context.read<AppState>().logout(),
          ),
        ],
      ),
    );
  }
}
