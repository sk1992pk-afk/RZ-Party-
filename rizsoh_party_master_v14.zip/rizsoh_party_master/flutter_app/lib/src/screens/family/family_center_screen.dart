import 'package:flutter/material.dart';

class FamilyCenterScreen extends StatelessWidget {
  const FamilyCenterScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final families = List.generate(6, (i) => 'Rizsoh Family ${i+1}');
    return Scaffold(
      appBar: AppBar(title: const Text('Family Center')),
      body: ListView.builder(
        itemCount: families.length,
        itemBuilder: (_, i) => Card(
          child: ListTile(
            title: Text(families[i]),
            subtitle: const Text('Level, members, leader, weekly points'),
            trailing: FilledButton(onPressed: () {}, child: const Text('Join')),
          ),
        ),
      ),
    );
  }
}
