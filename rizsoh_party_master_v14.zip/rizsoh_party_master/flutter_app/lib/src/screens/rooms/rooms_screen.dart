import 'package:flutter/material.dart';
import 'room_detail_screen.dart';

class RoomsScreen extends StatelessWidget {
  const RoomsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final rooms = List.generate(10, (i) => {
      'name': 'Luxury Room ${i + 1}',
      'host': 'Host ${i + 1}',
      'members': 10 + i * 4,
    });

    return Scaffold(
      appBar: AppBar(title: const Text('Voice Rooms')),
      body: ListView.builder(
        itemCount: rooms.length,
        itemBuilder: (_, i) {
          final room = rooms[i];
          return Card(
            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: ListTile(
              leading: const CircleAvatar(child: Icon(Icons.mic)),
              title: Text(room['name'].toString()),
              subtitle: Text('Host: ${room['host']} • ${room['members']} online'),
              trailing: FilledButton(
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (_) => RoomDetailScreen(roomName: room['name'].toString())));
                },
                child: const Text('Join'),
              ),
            ),
          );
        },
      ),
    );
  }
}
