import 'package:flutter/material.dart';

class RoomDetailScreen extends StatefulWidget {
  final String roomName;
  const RoomDetailScreen({super.key, required this.roomName});

  @override
  State<RoomDetailScreen> createState() => _RoomDetailScreenState();
}

class _RoomDetailScreenState extends State<RoomDetailScreen> {
  final seats = List.generate(8, (i) => i < 3 ? 'User ${i+1}' : null);
  bool muted = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.roomName)),
      body: Column(
        children: [
          const SizedBox(height: 12),
          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: List.generate(8, (i) {
              final user = seats[i];
              return Container(
                width: 100,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
                child: Column(
                  children: [
                    CircleAvatar(child: Icon(user == null ? Icons.mic_off : Icons.person)),
                    const SizedBox(height: 8),
                    Text(user ?? 'Seat ${i+1}', overflow: TextOverflow.ellipsis),
                    const SizedBox(height: 6),
                    Text(user == null ? 'Empty' : 'Speaking', style: const TextStyle(fontSize: 12)),
                  ],
                ),
              );
            }),
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: const BoxDecoration(color: Colors.white),
            child: Row(
              children: [
                Expanded(child: OutlinedButton(onPressed: () {}, child: const Text('Gift'))),
                const SizedBox(width: 8),
                Expanded(child: OutlinedButton(onPressed: () {}, child: const Text('Mute User'))),
                const SizedBox(width: 8),
                Expanded(child: FilledButton(onPressed: () => setState(()=> muted = !muted), child: Text(muted ? 'Unmute Me' : 'Mute Me'))),
              ],
            ),
          )
        ],
      ),
    );
  }
}
