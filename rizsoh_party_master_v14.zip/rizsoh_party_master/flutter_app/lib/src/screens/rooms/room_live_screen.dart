import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../features/app/app_state.dart';
import '../../services/realtime_service.dart';
import '../../services/rtc_api_service.dart';
import '../../services/media_engine_service.dart';
import '../../core/network/api_client.dart';

class RoomLiveScreen extends StatefulWidget {
  final String roomId;
  final String roomTitle;
  const RoomLiveScreen({super.key, required this.roomId, required this.roomTitle});

  @override
  State<RoomLiveScreen> createState() => _RoomLiveScreenState();
}

class _RoomLiveScreenState extends State<RoomLiveScreen> {
  final rt = RealtimeService();
  final media = MediaEngineService();
  final msg = TextEditingController();
  final List<String> feed = [];
  bool engineReady = false;

  final seats = List.generate(8, (i) => {'index': i + 1, 'user': i == 0 ? 'Host' : null, 'muted': false});

  @override
  void initState() {
    super.initState();
    Future.microtask(_boot);
  }

  Future<void> _boot() async {
    final appState = context.read<AppState>();
    final userId = appState.userId ?? 'guest';
    final api = RtcApiService(ApiClient(baseUrl: 'http://10.0.2.2:4000', token: appState.token));
    final rtc = await api.getRoomToken(roomId: widget.roomId, uid: userId);
    await media.initVoiceRoom(
      provider: rtc['provider'].toString(),
      appId: rtc['appId'].toString(),
      token: rtc['token'].toString(),
      channelId: widget.roomId,
      uid: userId,
    );
    rt.connect('http://10.0.2.2:4000');
    rt.joinRoom(widget.roomId, userId);
    rt.on('room_user_joined', (d) => setState(() => feed.add('User joined: ${d['userId']}')));
    rt.on('room_message', (d) => setState(() => feed.add(d['message']['body'].toString())));
    rt.on('room_gift', (d) => setState(() => feed.add('Gift: ${d['gift']['giftId']} x${d['gift']['qty']}')));
    rt.on('host_mute_user', (d) => setState(() => feed.add('Muted ${d['targetUserId']} for ${d['minutes']}m')));
    rt.on('host_kick_user', (d) => setState(() => feed.add('Kicked ${d['targetUserId']}')));
    if (mounted) setState(() => engineReady = true);
  }

  @override
  void dispose() {
    rt.leaveRoom(widget.roomId, context.read<AppState>().userId ?? 'guest');
    rt.dispose();
    media.leave();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final userId = context.read<AppState>().userId ?? 'guest';
    return Scaffold(
      appBar: AppBar(title: Text(widget.roomTitle)),
      body: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            alignment: Alignment.centerLeft,
            child: Text(engineReady ? 'Voice engine ready' : 'Preparing room...'),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: seats.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 4, childAspectRatio: .9),
              itemBuilder: (_, i) {
                final seat = seats[i];
                final occupied = seat['user'] != null;
                return Card(
                  child: InkWell(
                    onTap: () => setState(() => seat['user'] = occupied ? null : 'User ${i+1}'),
                    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      CircleAvatar(child: Text('${seat['index']}')),
                      const SizedBox(height: 8),
                      Text(occupied ? seat['user'].toString() : 'Empty'),
                      Text(occupied ? (seat['muted'] == true ? 'Muted' : 'Open Mic') : 'Tap to sit', style: const TextStyle(fontSize: 12)),
                    ]),
                  ),
                );
              },
            ),
          ),
          Expanded(child: ListView.builder(itemCount: feed.length, itemBuilder: (_, i) => ListTile(title: Text(feed[i])))),
          Wrap(
            spacing: 8,
            children: [
              ElevatedButton(onPressed: () => rt.sendRoomGift(widget.roomId, {'giftId': 'rose', 'qty': 1, 'from': userId}), child: const Text('Send Gift')),
              ElevatedButton(onPressed: () => rt.muteUser(widget.roomId, 'u2', 10), child: const Text('Mute U2')),
              ElevatedButton(onPressed: () => rt.kickUser(widget.roomId, 'u2'), child: const Text('Kick U2')),
            ],
          ),
          Padding(
            padding: const EdgeInsets.all(8),
            child: Row(children: [
              Expanded(child: TextField(controller: msg, decoration: const InputDecoration(hintText: 'Room message'))),
              IconButton(
                onPressed: () {
                  rt.sendRoomMessage(widget.roomId, {'body': msg.text.trim(), 'fromUserId': userId});
                  msg.clear();
                },
                icon: const Icon(Icons.send),
              )
            ]),
          )
        ],
      ),
    );
  }
}
