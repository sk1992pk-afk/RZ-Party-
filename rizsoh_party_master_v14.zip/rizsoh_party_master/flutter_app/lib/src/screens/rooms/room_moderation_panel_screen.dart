import 'package:flutter/material.dart';
import '../../core/network/api_client.dart';
import '../../services/moderation_api_service.dart';

class RoomModerationPanelScreen extends StatelessWidget {
  final String roomId;
  const RoomModerationPanelScreen({super.key, this.roomId = 'r1'});

  Future<void> _do(BuildContext context, String action) async {
    final api = ModerationApiService(ApiClient(baseUrl: 'http://10.0.2.2:4000'));
    Map<String, dynamic> res = {};
    if (action == 'mute') {
      res = await api.mute(roomId, {'targetUserId': 'u2', 'moderatorId': 'u1', 'minutes': 10});
    } else if (action == 'kick') {
      res = await api.kick(roomId, {'targetUserId': 'u2', 'moderatorId': 'u1'});
    } else {
      res = await api.ban(roomId, {'targetUserId': 'u2', 'moderatorId': 'u1', 'reason': 'abuse'});
    }
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(res['message']?.toString() ?? 'Action completed')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Room Moderation')),
      body: ListView(
        children: [
          ListTile(title: const Text('Mute user'), onTap: () => _do(context, 'mute')),
          ListTile(title: const Text('Kick user'), onTap: () => _do(context, 'kick')),
          ListTile(title: const Text('Ban user'), onTap: () => _do(context, 'ban')),
        ],
      ),
    );
  }
}
