import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/network/api_client.dart';
import '../../features/app/app_state.dart';
import '../../services/chat_api_service.dart';

class ChatConversationScreen extends StatefulWidget {
  final String conversationId;
  const ChatConversationScreen({super.key, required this.conversationId});

  @override
  State<ChatConversationScreen> createState() => _ChatConversationScreenState();
}

class _ChatConversationScreenState extends State<ChatConversationScreen> {
  final controller = TextEditingController();
  bool loading = true;
  List<dynamic> messages = [];

  @override
  void initState() { super.initState(); Future.microtask(_load); }

  Future<void> _load() async {
    final api = ChatApiService(ApiClient(baseUrl: 'http://10.0.2.2:4000', token: context.read<AppState>().token));
    messages = await api.getConversation(widget.conversationId);
    if (mounted) setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    final api = ChatApiService(ApiClient(baseUrl: 'http://10.0.2.2:4000', token: context.read<AppState>().token));
    return Scaffold(
      appBar: AppBar(title: Text('Chat ${widget.conversationId}')),
      body: Column(
        children: [
          Expanded(
            child: loading ? const Center(child: CircularProgressIndicator()) : ListView.builder(
              itemCount: messages.length,
              itemBuilder: (_, i) {
                final m = messages[i] as Map<String, dynamic>;
                return ListTile(title: Text(m['body']?.toString() ?? ''));
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8),
            child: Row(children: [
              Expanded(child: TextField(controller: controller, decoration: const InputDecoration(hintText: 'Type message'))),
              IconButton(
                onPressed: () async {
                  await api.sendMessage(widget.conversationId, controller.text.trim());
                  controller.clear();
                  await _load();
                },
                icon: const Icon(Icons.send),
              )
            ]),
          )
        ],
      ),
    );
  }
}
