import 'package:flutter/material.dart';
import 'chat_conversation_screen.dart';

class InboxListScreen extends StatelessWidget {
  const InboxListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final demo = const [
      {'id': 'support_1', 'name': 'Support'},
      {'id': 'family_1', 'name': 'Family Chat'},
      {'id': 'host_42', 'name': 'Host Noor'},
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('Inbox')),
      body: ListView.builder(
        itemCount: demo.length,
        itemBuilder: (_, i) {
          final item = demo[i];
          return ListTile(
            leading: const CircleAvatar(child: Icon(Icons.person)),
            title: Text(item['name']!),
            subtitle: Text(item['id']!),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => ChatConversationScreen(conversationId: item['id']!)),
            ),
          );
        },
      ),
    );
  }
}
