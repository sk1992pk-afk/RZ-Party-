import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../features/reports/report_provider.dart';

class ReportSubmitScreen extends StatefulWidget {
  final String targetId;
  final String type;
  const ReportSubmitScreen({super.key, required this.targetId, required this.type});

  @override
  State<ReportSubmitScreen> createState() => _ReportSubmitScreenState();
}

class _ReportSubmitScreenState extends State<ReportSubmitScreen> {
  final controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ReportProvider>();
    return Scaffold(
      appBar: AppBar(title: const Text('Submit Report')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Text('Report ${widget.type}: ${widget.targetId}'),
            const SizedBox(height: 12),
            TextField(
              controller: controller,
              maxLines: 5,
              decoration: const InputDecoration(
                hintText: 'Describe the issue',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: provider.submitting ? null : () async {
                await context.read<ReportProvider>().submit(
                  type: widget.type,
                  targetId: widget.targetId,
                  reason: controller.text.trim(),
                );
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text(provider.lastStatus ?? 'Report submitted')),
                  );
                }
              },
              child: Text(provider.submitting ? 'Submitting...' : 'Submit report'),
            )
          ],
        ),
      ),
    );
  }
}
