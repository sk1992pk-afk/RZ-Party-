import 'package:flutter/material.dart';
import '../../core/network/api_client.dart';
import '../../services/report_api_service.dart';
import 'report_submit_screen.dart';

class ReportCenterScreen extends StatefulWidget {
  const ReportCenterScreen({super.key});

  @override
  State<ReportCenterScreen> createState() => _ReportCenterScreenState();
}

class _ReportCenterScreenState extends State<ReportCenterScreen> {
  List<dynamic> reports = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final api = ReportApiService(ApiClient(baseUrl: 'http://10.0.2.2:4000'));
    reports = await api.getReports();
    if (mounted) setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Safety Reports')),
      floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.push(context, MaterialPageRoute(
          builder: (_) => const ReportSubmitScreen(targetId: 'u2', type: 'user'),
        )),
        child: const Icon(Icons.add),
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : reports.isEmpty
              ? const Center(child: Text('No reports yet'))
              : ListView.builder(
                  itemCount: reports.length,
                  itemBuilder: (_, i) {
                    final r = reports[i] as Map<String, dynamic>;
                    return ListTile(
                      title: Text('${r['type']} • ${r['targetId']}'),
                      subtitle: Text(r['reason']?.toString() ?? ''),
                      trailing: Text(r['status']?.toString() ?? ''),
                    );
                  },
                ),
    );
  }
}
