import 'package:flutter/material.dart';

class WalletScreen extends StatelessWidget {
  const WalletScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Wallet')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(child: ListTile(title: const Text('Coins'), trailing: const Text('12,500'))),
          Card(child: ListTile(title: const Text('Diamonds'), trailing: const Text('4,220'))),
          Card(child: ListTile(title: const Text('Earnings'), trailing: const Text('PKR 32,000'))),
          const SizedBox(height: 16),
          FilledButton(onPressed: () {}, child: const Text('Recharge')),
          const SizedBox(height: 8),
          OutlinedButton(onPressed: () {}, child: const Text('Withdraw')),
        ],
      ),
    );
  }
}
