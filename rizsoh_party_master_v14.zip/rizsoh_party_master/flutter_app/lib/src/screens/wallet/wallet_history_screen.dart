import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../features/wallet/wallet_provider.dart';

class WalletHistoryScreen extends StatefulWidget {
  const WalletHistoryScreen({super.key});

  @override
  State<WalletHistoryScreen> createState() => _WalletHistoryScreenState();
}

class _WalletHistoryScreenState extends State<WalletHistoryScreen> {
  @override
  void initState() {
    super.initState();
    Future.microtask(() => context.read<WalletProvider>().loadTransactions());
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<WalletProvider>();
    return Scaffold(
      appBar: AppBar(title: const Text('Wallet History')),
      body: provider.loading
          ? const Center(child: CircularProgressIndicator())
          : provider.transactions.isEmpty
              ? const Center(child: Text('No wallet transactions yet'))
              : ListView.builder(
                  itemCount: provider.transactions.length,
                  itemBuilder: (_, i) {
                    final tx = provider.transactions[i] as Map<String, dynamic>;
                    return ListTile(
                      title: Text(tx['type']?.toString() ?? 'transaction'),
                      subtitle: Text(tx['createdAt']?.toString() ?? ''),
                      trailing: Text('${tx['amount'] ?? ''} ${tx['currency'] ?? ''}'),
                    );
                  },
                ),
    );
  }
}
