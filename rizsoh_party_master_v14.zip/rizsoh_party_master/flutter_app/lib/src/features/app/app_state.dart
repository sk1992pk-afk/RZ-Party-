import 'package:flutter/foundation.dart';
import '../../core/storage/session_storage.dart';

class AppState extends ChangeNotifier {
  final SessionStorage storage;
  AppState(this.storage);

  bool initialized = false;
  bool loggedIn = false;
  String? token;
  String? userId;

  Future<void> bootstrap() async {
    token = await storage.getToken();
    userId = await storage.getUserId();
    loggedIn = token != null && userId != null;
    initialized = true;
    notifyListeners();
  }

  Future<void> setSession(String tokenValue, String userIdValue) async {
    token = tokenValue;
    userId = userIdValue;
    loggedIn = true;
    await storage.saveSession(token: tokenValue, userId: userIdValue);
    notifyListeners();
  }

  Future<void> logout() async {
    await storage.clear();
    token = null;
    userId = null;
    loggedIn = false;
    notifyListeners();
  }
}
