import 'package:flutter/foundation.dart';
import '../../services/report_api_service.dart';

class ReportProvider extends ChangeNotifier {
  final ReportApiService api;
  ReportProvider(this.api);

  bool submitting = false;
  String? lastStatus;

  Future<void> submit({
    required String type,
    required String targetId,
    required String reason,
  }) async {
    submitting = true;
    notifyListeners();
    try {
      final res = await api.submitReport(type: type, targetId: targetId, reason: reason);
      lastStatus = res['message']?.toString() ?? 'submitted';
    } finally {
      submitting = false;
      notifyListeners();
    }
  }
}
