import 'package:flutter/foundation.dart';
import '../../services/gift_api_service.dart';

class GiftProvider extends ChangeNotifier {
  final GiftApiService api;
  GiftProvider(this.api);

  bool sending = false;
  String? lastMessage;

  Future<bool> sendGift({
    required String fromUserId,
    required String toUserId,
    required String targetType,
    required String targetId,
    required String giftId,
    int qty = 1,
  }) async {
    sending = true;
    notifyListeners();
    try {
      final res = await api.sendGift(
        fromUserId: fromUserId,
        toUserId: toUserId,
        targetType: targetType,
        targetId: targetId,
        giftId: giftId,
        qty: qty,
      );
      lastMessage = res['message']?.toString() ?? 'Gift sent';
      return res['tx'] != null || res['message'] != null;
    } catch (_) {
      lastMessage = 'Gift send failed';
      return false;
    } finally {
      sending = false;
      notifyListeners();
    }
  }
}
