import 'package:flutter/foundation.dart';
import '../../services/wallet_api_service.dart';

class WalletProvider extends ChangeNotifier {
  final WalletApiService api;
  WalletProvider(this.api);

  bool loading = false;
  List<dynamic> transactions = [];
  int coinsBalance = 0;
  int diamondsBalance = 0;

  Future<void> loadTransactions() async {
    loading = true;
    notifyListeners();
    try {
      transactions = await api.getTransactions();
      _syncBalances();
    } finally {
      loading = false;
      notifyListeners();
    }
  }

  void _syncBalances() {
    int coins = 0;
    int diamonds = 0;
    for (final row in transactions) {
      final tx = row as Map<String, dynamic>;
      final currency = tx['currency']?.toString() ?? '';
      final direction = tx['direction']?.toString() ?? '';
      final amount = (tx['amount'] is num) ? (tx['amount'] as num).toInt() : int.tryParse('${tx['amount']}') ?? 0;
      final signed = direction == 'debit' ? -amount : amount;
      if (currency == 'coins') coins += signed;
      if (currency == 'diamonds') diamonds += signed;
    }
    coinsBalance = coins;
    diamondsBalance = diamonds;
  }
}
