import 'package:socket_io_client/socket_io_client.dart' as IO;

class SocketService {
  IO.Socket? socket;

  void connect(String baseUrl) {
    socket = IO.io(baseUrl, <String, dynamic>{
      'transports': ['websocket'],
      'autoConnect': true,
    });
  }

  void joinRoom(String roomId, Map<String, dynamic> user) {
    socket?.emit('room:join', {'roomId': roomId, 'user': user});
  }

  void sendRoomGift(String roomId, Map<String, dynamic> payload) {
    socket?.emit('room:gift', {'roomId': roomId, ...payload});
  }

  void sendLiveComment(String liveId, String user, String message) {
    socket?.emit('live:comment', {'liveId': liveId, 'user': user, 'message': message});
  }

  void dispose() {
    socket?.dispose();
  }
}
