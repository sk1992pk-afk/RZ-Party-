import '../core/network/api_client.dart';

class ReportApiService {
  final ApiClient api;
  ReportApiService(this.api);

  Future<List<dynamic>> getReports() async {
    final res = await api.get('/api/reports');
    return res is List ? res : [];
  }

  Future<Map<String, dynamic>> submitReport({
    required String type,
    required String targetId,
    required String reason,
  }) async {
    return await api.post('/api/reports', {
      'type': type,
      'targetId': targetId,
      'reason': reason,
    });
  }
}
