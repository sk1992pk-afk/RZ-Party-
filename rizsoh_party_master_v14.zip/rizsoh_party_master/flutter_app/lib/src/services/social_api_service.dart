import '../core/network/api_client.dart';

class SocialApiService {
  final ApiClient api;
  SocialApiService(this.api);

  Future<List<dynamic>> getFamilies() async => await api.get('/api/family');
  Future<List<dynamic>> getAgencies() async => await api.get('/api/agency');
  Future<List<dynamic>> getRooms() async => await api.get('/api/rooms');
  Future<List<dynamic>> getLives() async => await api.get('/api/live');

  Future<Map<String, dynamic>> createFamily(String name, {String bio = ''}) async =>
      Map<String, dynamic>.from(await api.post('/api/family', {'name': name, 'bio': bio}));

  Future<Map<String, dynamic>> createAgency(String name, String code) async =>
      Map<String, dynamic>.from(await api.post('/api/agency', {'name': name, 'code': code}));

  Future<Map<String, dynamic>> createRoom(String title) async =>
      Map<String, dynamic>.from(await api.post('/api/rooms', {'title': title}));

  Future<Map<String, dynamic>> startLive(String title) async =>
      Map<String, dynamic>.from(await api.post('/api/live/start', {'title': title}));
}
