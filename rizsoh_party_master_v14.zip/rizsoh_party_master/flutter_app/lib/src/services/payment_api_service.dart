import '../core/network/api_client.dart';

class PaymentApiService {
  final ApiClient api;
  PaymentApiService(this.api);

  Future<List<dynamic>> getMyRecharges() async {
    final res = await api.get('/api/payments/recharge/my');
    return res as List<dynamic>;
  }

  Future<List<dynamic>> getMyWithdraws() async {
    final res = await api.get('/api/payments/withdraw/my');
    return res as List<dynamic>;
  }

  Future<Map<String, dynamic>> submitRecharge({
    required int amount,
    required String method,
    required String senderAccount,
    required String transactionId,
  }) async {
    return await api.post('/api/payments/recharge', {
      'amount': amount,
      'method': method,
      'senderAccount': senderAccount,
      'transactionId': transactionId,
    });
  }

  Future<Map<String, dynamic>> submitWithdraw({
    required int amount,
    required String method,
    required String accountTitle,
    required String accountNumber,
  }) async {
    return await api.post('/api/payments/withdraw', {
      'amount': amount,
      'method': method,
      'accountTitle': accountTitle,
      'accountNumber': accountNumber,
    });
  }
}
