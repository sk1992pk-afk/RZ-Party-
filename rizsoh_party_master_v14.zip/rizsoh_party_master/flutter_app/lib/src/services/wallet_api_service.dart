import '../core/network/api_client.dart';

class WalletApiService {
  final ApiClient api;
  WalletApiService(this.api);

  Future<List<dynamic>> getTransactions() async {
    final res = await api.get('/api/wallet/transactions');
    return res is List ? res : [];
  }

  Future<Map<String, dynamic>> submitRecharge({
    required String userId,
    required int amount,
    required String method,
    required String senderAccount,
    required String transactionId,
  }) async {
    return await api.post('/api/payments/recharge-request', {
      'userId': userId,
      'amount': amount,
      'method': method,
      'senderAccount': senderAccount,
      'transactionId': transactionId,
    });
  }
}
