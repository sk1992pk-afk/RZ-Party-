import '../core/network/api_client.dart';

class ModerationApiService {
  final ApiClient api;
  ModerationApiService(this.api);

  Future<List<dynamic>> getActions(String roomId) async {
    final res = await api.get('/api/rooms/moderation/$roomId/actions');
    return res is List ? res : [];
  }

  Future<Map<String, dynamic>> mute(String roomId, Map<String, dynamic> body) async =>
      await api.post('/api/rooms/moderation/$roomId/mute', body);

  Future<Map<String, dynamic>> kick(String roomId, Map<String, dynamic> body) async =>
      await api.post('/api/rooms/moderation/$roomId/kick', body);

  Future<Map<String, dynamic>> ban(String roomId, Map<String, dynamic> body) async =>
      await api.post('/api/rooms/moderation/$roomId/ban', body);
}
