import '../core/network/api_client.dart';

class GiftApiService {
  final ApiClient api;
  GiftApiService(this.api);

  Future<List<dynamic>> getGiftTransactions() async {
    final res = await api.get('/api/gifts/transactions');
    return res is List ? res : [];
  }

  Future<Map<String, dynamic>> sendGift({
    required String fromUserId,
    required String toUserId,
    required String targetType,
    required String targetId,
    required String giftId,
    int qty = 1,
  }) async {
    return await api.post('/api/gifts/send-advanced', {
      'fromUserId': fromUserId,
      'toUserId': toUserId,
      'targetType': targetType,
      'targetId': targetId,
      'giftId': giftId,
      'qty': qty,
    });
  }
}
