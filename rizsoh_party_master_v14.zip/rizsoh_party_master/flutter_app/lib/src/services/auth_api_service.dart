import '../core/network/api_client.dart';

class AuthApiService {
  final ApiClient api;
  AuthApiService(this.api);

  Future<Map<String, dynamic>> login({
    required String phone,
    required String password,
  }) async {
    return Map<String, dynamic>.from(await api.post('/api/auth/login', {
      'phone': phone,
      'password': password,
    }));
  }

  Future<Map<String, dynamic>> register({
    required String name,
    required String phone,
    required String password,
  }) async {
    return Map<String, dynamic>.from(await api.post('/api/auth/register', {
      'name': name,
      'phone': phone,
      'password': password,
    }));
  }
}
