import '../core/network/api_client.dart';

class ChatApiService {
  final ApiClient api;
  ChatApiService(this.api);

  Future<List<dynamic>> getConversation(String conversationId) async {
    final res = await api.get('/api/chat/conversation/$conversationId');
    return res as List<dynamic>;
  }

  Future<Map<String, dynamic>> sendMessage(String conversationId, String body) async {
    final res = await api.post('/api/chat/conversation/$conversationId', {'body': body});
    return Map<String, dynamic>.from(res as Map);
  }
}
