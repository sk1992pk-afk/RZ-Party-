class PushNotificationService {
  Future<void> initialize() async {
    // TODO: integrate firebase_messaging
    // - request permission
    // - get FCM token
    // - send token to backend /api/push/register
    // - handle foreground/background notifications
  }
}
