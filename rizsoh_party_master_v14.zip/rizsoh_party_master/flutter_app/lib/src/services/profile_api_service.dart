import '../core/network/api_client.dart';

class ProfileApiService {
  final ApiClient api;
  ProfileApiService(this.api);

  Future<Map<String, dynamic>> getMe() async {
    final res = await api.get('/api/profile/me');
    return Map<String, dynamic>.from(res as Map);
  }

  Future<Map<String, dynamic>> updateMe(Map<String, dynamic> body) async {
    final res = await api.patch('/api/profile/me', body);
    return Map<String, dynamic>.from(res as Map);
  }
}
