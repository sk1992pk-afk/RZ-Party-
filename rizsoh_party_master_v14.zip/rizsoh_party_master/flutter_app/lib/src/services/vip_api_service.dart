import '../core/network/api_client.dart';
import '../models/vip_profile_card.dart';

class VipApiService {
  final ApiClient api;
  VipApiService(this.api);

  Future<List<dynamic>> getBenefits(int vipLevel) async {
    final res = await api.get('/api/vip/benefits/$vipLevel');
    return List<String>.from(res['benefits'] ?? const []);
  }

  Future<VipProfileCard?> getProfileCard(String userId) async {
    final res = await api.get('/api/vip/profile-card/$userId');
    if (res is Map<String, dynamic> && res['id'] != null) {
      return VipProfileCard.fromJson(res);
    }
    return null;
  }
}
