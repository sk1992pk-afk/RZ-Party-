import 'package:socket_io_client/socket_io_client.dart' as IO;

class RealtimeService {
  IO.Socket? socket;

  void connect(String baseUrl) {
    socket = IO.io(baseUrl, <String, dynamic>{
      'transports': ['websocket'],
      'autoConnect': true,
    });
  }

  void joinRoom(String roomId, String userId) => socket?.emit('join_room', {'roomId': roomId, 'userId': userId});
  void leaveRoom(String roomId, String userId) => socket?.emit('leave_room', {'roomId': roomId, 'userId': userId});
  void sendRoomMessage(String roomId, Map<String, dynamic> message) => socket?.emit('room_message', {'roomId': roomId, 'message': message});
  void sendRoomGift(String roomId, Map<String, dynamic> gift) => socket?.emit('room_gift', {'roomId': roomId, 'gift': gift});
  void muteUser(String roomId, String targetUserId, int minutes) => socket?.emit('host_mute_user', {'roomId': roomId, 'targetUserId': targetUserId, 'minutes': minutes});
  void kickUser(String roomId, String targetUserId) => socket?.emit('host_kick_user', {'roomId': roomId, 'targetUserId': targetUserId});

  void joinLive(String liveId, String userId) => socket?.emit('join_live', {'liveId': liveId, 'userId': userId});
  void leaveLive(String liveId, String userId) => socket?.emit('leave_live', {'liveId': liveId, 'userId': userId});
  void sendLiveComment(String liveId, Map<String, dynamic> comment) => socket?.emit('live_comment', {'liveId': liveId, 'comment': comment});
  void sendLiveGift(String liveId, Map<String, dynamic> gift) => socket?.emit('live_gift', {'liveId': liveId, 'gift': gift});

  void on(String event, Function(dynamic) handler) => socket?.on(event, handler);
  void dispose() => socket?.dispose();
}
