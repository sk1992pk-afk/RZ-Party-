import '../core/network/api_client.dart';

class RtcApiService {
  final ApiClient api;
  RtcApiService(this.api);

  Future<Map<String, dynamic>> getRoomToken({
    required String roomId,
    required String uid,
  }) async {
    final res = await api.post('/api/rtc/room-token', {'roomId': roomId, 'uid': uid});
    return Map<String, dynamic>.from(res as Map);
  }

  Future<Map<String, dynamic>> getLiveToken({
    required String liveId,
    required String uid,
    String role = 'audience',
  }) async {
    final res = await api.post('/api/rtc/live-token', {'liveId': liveId, 'uid': uid, 'role': role});
    return Map<String, dynamic>.from(res as Map);
  }
}
