class MediaEngineService {
  Future<void> initVoiceRoom({
    required String provider,
    required String appId,
    required String token,
    required String channelId,
    required String uid,
  }) async {
    // TODO: replace with Agora/Zego engine init
  }

  Future<void> initLive({
    required String provider,
    required String appId,
    required String token,
    required String channelId,
    required String uid,
    required bool isHost,
  }) async {
    // TODO: replace with Agora/Zego live engine init
  }

  Future<void> leave() async {}
}
