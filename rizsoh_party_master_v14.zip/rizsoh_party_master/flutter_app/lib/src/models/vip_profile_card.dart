class VipProfileCard {
  final String id;
  final String name;
  final int vipLevel;
  final int level;
  final List<String> badges;
  final List<String> benefits;

  VipProfileCard({
    required this.id,
    required this.name,
    required this.vipLevel,
    required this.level,
    required this.badges,
    required this.benefits,
  });

  factory VipProfileCard.fromJson(Map<String, dynamic> json) => VipProfileCard(
        id: json['id'] ?? '',
        name: json['name'] ?? '',
        vipLevel: json['vipLevel'] ?? 0,
        level: json['level'] ?? 0,
        badges: List<String>.from(json['badges'] ?? const []),
        benefits: List<String>.from(json['benefits'] ?? const []),
      );
}
