class ReportItem {
  final String id;
  final String type;
  final String targetId;
  final String reason;
  final String status;

  ReportItem({
    required this.id,
    required this.type,
    required this.targetId,
    required this.reason,
    required this.status,
  });
}
