# Rizsoh Party Android APK Prep Checklist

## 1) Android package
- applicationId: com.rizsoh.party
- app name: Rizsoh Party
- minSdkVersion: verify with live SDK choice (Agora/Zego may require higher levels)

## 2) Signing
Create release keystore and configure:
- android/key.properties
- android/app/build.gradle(.kts) signingConfig
- storeFile / storePassword / keyAlias / keyPassword

## 3) Environment
Set production API URL in app config:
- API base URL
- Socket base URL
- FCM project config

## 4) Assets
- final pink/white/gold logo
- splash screen
- launcher icons
- app screenshots

## 5) Build
flutter clean
flutter pub get
flutter build apk --release
