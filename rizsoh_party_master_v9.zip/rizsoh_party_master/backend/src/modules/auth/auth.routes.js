const router = require('express').Router();
const { db } = require('../../db/inMemoryDb');

router.post('/login', (req, res) => {
  const phone = req.body.phone || '';
  const user = db.users.find(u => u.phone === phone) || db.users[0];
  return res.json({
    message: 'login success',
    token: 'demo_token_' + user.id,
    user: { id: user.id, name: user.name, phone: user.phone }
  });
});

module.exports = router;
