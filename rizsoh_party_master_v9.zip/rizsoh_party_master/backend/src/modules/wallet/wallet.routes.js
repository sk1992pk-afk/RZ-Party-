const router = require('express').Router();
const { db } = require('../../db/inMemoryDb');

router.get('/transactions', (req, res) => {
  res.json(db.walletTransactions || []);
});

module.exports = router;
