import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../features/app/app_state.dart';
import '../../services/realtime_service.dart';

class RoomLiveScreen extends StatefulWidget {
  final String roomId;
  final String roomTitle;
  const RoomLiveScreen({super.key, required this.roomId, required this.roomTitle});

  @override
  State<RoomLiveScreen> createState() => _RoomLiveScreenState();
}

class _RoomLiveScreenState extends State<RoomLiveScreen> {
  final rt = RealtimeService();
  final msg = TextEditingController();
  final List<String> feed = [];

  @override
  void initState() {
    super.initState();
    final userId = context.read<AppState>().userId ?? 'guest';
    rt.connect('http://10.0.2.2:4000');
    rt.joinRoom(widget.roomId, userId);
    rt.on('room_user_joined', (d) => setState(() => feed.add('User joined: ${d['userId']}')));
    rt.on('room_message', (d) => setState(() => feed.add(d['message']['body'].toString())));
    rt.on('room_gift', (d) => setState(() => feed.add('Gift: ${d['gift']['giftId']} x${d['gift']['qty']}')));
    rt.on('host_mute_user', (d) => setState(() => feed.add('Muted ${d['targetUserId']} for ${d['minutes']}m')));
    rt.on('host_kick_user', (d) => setState(() => feed.add('Kicked ${d['targetUserId']}')));
  }

  @override
  void dispose() {
    rt.leaveRoom(widget.roomId, context.read<AppState>().userId ?? 'guest');
    rt.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final userId = context.read<AppState>().userId ?? 'guest';
    return Scaffold(
      appBar: AppBar(title: Text(widget.roomTitle)),
      body: Column(
        children: [
          Expanded(child: ListView.builder(itemCount: feed.length, itemBuilder: (_, i) => ListTile(title: Text(feed[i])))),
          Wrap(
            spacing: 8,
            children: [
              ElevatedButton(onPressed: () => rt.sendRoomGift(widget.roomId, {'giftId': 'rose', 'qty': 1, 'from': userId}), child: const Text('Send Gift')),
              ElevatedButton(onPressed: () => rt.muteUser(widget.roomId, 'u2', 10), child: const Text('Mute U2')),
              ElevatedButton(onPressed: () => rt.kickUser(widget.roomId, 'u2'), child: const Text('Kick U2')),
            ],
          ),
          Padding(
            padding: const EdgeInsets.all(8),
            child: Row(children: [
              Expanded(child: TextField(controller: msg, decoration: const InputDecoration(hintText: 'Room message'))),
              IconButton(
                onPressed: () {
                  rt.sendRoomMessage(widget.roomId, {'body': msg.text.trim(), 'fromUserId': userId});
                  msg.clear();
                },
                icon: const Icon(Icons.send),
              )
            ]),
          )
        ],
      ),
    );
  }
}
