import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/network/api_client.dart';
import '../../features/app/app_state.dart';
import '../../services/social_api_service.dart';

class FamilyListScreen extends StatefulWidget {
  const FamilyListScreen({super.key});
  @override
  State<FamilyListScreen> createState() => _FamilyListScreenState();
}

class _FamilyListScreenState extends State<FamilyListScreen> {
  bool loading = true;
  List<dynamic> rows = [];

  @override
  void initState() { super.initState(); Future.microtask(_load); }

  Future<void> _load() async {
    final api = SocialApiService(ApiClient(baseUrl: 'http://10.0.2.2:4000', token: context.read<AppState>().token));
    rows = await api.getFamilies();
    if (mounted) setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    final api = SocialApiService(ApiClient(baseUrl: 'http://10.0.2.2:4000', token: context.read<AppState>().token));
    return Scaffold(
      appBar: AppBar(title: const Text('Families')),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          await api.createFamily('Rizsoh Family');
          if (mounted) { setState(() => loading = true); await _load(); }
        },
        child: const Icon(Icons.add),
      ),
      body: loading ? const Center(child: CircularProgressIndicator()) : ListView.builder(
        itemCount: rows.length,
        itemBuilder: (_, i) {
          final r = rows[i] as Map<String, dynamic>;
          return ListTile(title: Text(r['name']?.toString() ?? 'Family'), subtitle: Text(r['bio']?.toString() ?? ''));
        },
      ),
    );
  }
}
