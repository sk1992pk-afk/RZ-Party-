import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/network/api_client.dart';
import '../../features/app/app_state.dart';
import '../../services/social_api_service.dart';

class AgencyListScreen extends StatefulWidget {
  const AgencyListScreen({super.key});
  @override
  State<AgencyListScreen> createState() => _AgencyListScreenState();
}

class _AgencyListScreenState extends State<AgencyListScreen> {
  bool loading = true;
  List<dynamic> rows = [];
  @override
  void initState() { super.initState(); Future.microtask(_load); }

  Future<void> _load() async {
    final api = SocialApiService(ApiClient(baseUrl: 'http://10.0.2.2:4000', token: context.read<AppState>().token));
    rows = await api.getAgencies();
    if (mounted) setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    final api = SocialApiService(ApiClient(baseUrl: 'http://10.0.2.2:4000', token: context.read<AppState>().token));
    return Scaffold(
      appBar: AppBar(title: const Text('Agencies')),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          await api.createAgency('Rizsoh Agency', 'RZ001');
          if (mounted) { setState(() => loading = true); await _load(); }
        },
        child: const Icon(Icons.add_business),
      ),
      body: loading ? const Center(child: CircularProgressIndicator()) : ListView.builder(
        itemCount: rows.length,
        itemBuilder: (_, i) {
          final r = rows[i] as Map<String, dynamic>;
          return ListTile(title: Text(r['name']?.toString() ?? 'Agency'), subtitle: Text(r['code']?.toString() ?? ''));
        },
      ),
    );
  }
}
