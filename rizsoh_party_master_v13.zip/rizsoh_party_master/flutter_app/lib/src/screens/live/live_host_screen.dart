import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../features/app/app_state.dart';
import '../../services/realtime_service.dart';

class LiveHostScreen extends StatefulWidget {
  final String liveId;
  final String title;
  const LiveHostScreen({super.key, required this.liveId, required this.title});

  @override
  State<LiveHostScreen> createState() => _LiveHostScreenState();
}

class _LiveHostScreenState extends State<LiveHostScreen> {
  final rt = RealtimeService();
  final comment = TextEditingController();
  final List<String> feed = [];

  @override
  void initState() {
    super.initState();
    final userId = context.read<AppState>().userId ?? 'guest';
    rt.connect('http://10.0.2.2:4000');
    rt.joinLive(widget.liveId, userId);
    rt.on('live_viewer_joined', (d) => setState(() => feed.add('Viewer joined: ${d['userId']}')));
    rt.on('live_comment', (d) => setState(() => feed.add(d['comment']['body'].toString())));
    rt.on('live_gift', (d) => setState(() => feed.add('Live gift: ${d['gift']['giftId']} x${d['gift']['qty']}')));
  }

  @override
  void dispose() {
    rt.leaveLive(widget.liveId, context.read<AppState>().userId ?? 'guest');
    rt.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final userId = context.read<AppState>().userId ?? 'guest';
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: Column(
        children: [
          Expanded(child: ListView.builder(itemCount: feed.length, itemBuilder: (_, i) => ListTile(title: Text(feed[i])))),
          Wrap(
            spacing: 8,
            children: [
              ElevatedButton(onPressed: () => rt.sendLiveGift(widget.liveId, {'giftId': 'car', 'qty': 1, 'from': userId}), child: const Text('Send Gift')),
            ],
          ),
          Padding(
            padding: const EdgeInsets.all(8),
            child: Row(children: [
              Expanded(child: TextField(controller: comment, decoration: const InputDecoration(hintText: 'Live comment'))),
              IconButton(
                onPressed: () {
                  rt.sendLiveComment(widget.liveId, {'body': comment.text.trim(), 'fromUserId': userId});
                  comment.clear();
                },
                icon: const Icon(Icons.send),
              )
            ]),
          )
        ],
      ),
    );
  }
}
