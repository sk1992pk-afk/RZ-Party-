import '../core/network/api_client.dart';

class AuthApiService {
  final ApiClient api;
  AuthApiService(this.api);

  Future<Map<String, dynamic>> login({
    required String phone,
    required String password,
  }) async {
    return await api.post('/api/auth/login', {
      'phone': phone,
      'password': password,
    });
  }
}
