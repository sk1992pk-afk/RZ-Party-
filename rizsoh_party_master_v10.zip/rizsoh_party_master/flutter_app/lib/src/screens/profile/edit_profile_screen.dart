import 'package:flutter/material.dart';

class EditProfileScreen extends StatelessWidget {
  const EditProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Edit Profile')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: const [
          CircleAvatar(radius: 42, child: Icon(Icons.person, size: 42)),
          SizedBox(height: 16),
          TextField(decoration: InputDecoration(labelText: 'Nickname')),
          SizedBox(height: 12),
          TextField(decoration: InputDecoration(labelText: 'Bio')),
          SizedBox(height: 12),
          TextField(decoration: InputDecoration(labelText: 'Country')),
          SizedBox(height: 12),
          TextField(decoration: InputDecoration(labelText: 'Gender')),
        ],
      ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: EdgeInsets.all(16),
          child: FilledButton(onPressed: null, child: Text('Save Changes')),
        ),
      ),
    );
  }
}
