import 'package:flutter/material.dart';

class LiveHostScreen extends StatelessWidget {
  const LiveHostScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final comments = List.generate(6, (i) => 'Viewer ${i+1}: Nice live!');
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          const Center(child: Icon(Icons.videocam, color: Colors.white54, size: 120)),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                children: [
                  Row(
                    children: [
                      const CircleAvatar(child: Icon(Icons.person)),
                      const SizedBox(width: 8),
                      const Expanded(child: Text('Host Live Room', style: TextStyle(color: Colors.white))),
                      IconButton(onPressed: () {}, icon: const Icon(Icons.close, color: Colors.white)),
                    ],
                  ),
                  const Spacer(),
                  Align(
                    alignment: Alignment.bottomLeft,
                    child: SizedBox(
                      width: 250,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: comments.map((e) => Container(
                          margin: const EdgeInsets.only(top: 6),
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                          decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(16)),
                          child: Text(e, style: const TextStyle(color: Colors.white)),
                        )).toList(),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(child: TextField(decoration: InputDecoration(fillColor: Colors.white, filled: true, hintText: 'Say something...'))),
                      const SizedBox(width: 8),
                      FloatingActionButton.small(onPressed: () {}, child: const Icon(Icons.card_giftcard)),
                    ],
                  )
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}
