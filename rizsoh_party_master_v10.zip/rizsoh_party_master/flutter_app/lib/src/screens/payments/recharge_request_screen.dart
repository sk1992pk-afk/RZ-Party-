import 'package:flutter/material.dart';
import '../../services/wallet_api_service.dart';
import '../../core/network/api_client.dart';

class RechargeRequestScreen extends StatefulWidget {
  const RechargeRequestScreen({super.key});

  @override
  State<RechargeRequestScreen> createState() => _RechargeRequestScreenState();
}

class _RechargeRequestScreenState extends State<RechargeRequestScreen> {
  final amount = TextEditingController();
  final sender = TextEditingController();
  final txid = TextEditingController();
  String method = 'JazzCash';
  bool loading = false;

  @override
  Widget build(BuildContext context) {
    final api = WalletApiService(ApiClient(baseUrl: 'http://10.0.2.2:4000'));
    return Scaffold(
      appBar: AppBar(title: const Text('Recharge Request')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          DropdownButtonFormField<String>(
            value: method,
            items: const ['JazzCash', 'EasyPaisa'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
            onChanged: (v) => setState(() => method = v ?? 'JazzCash'),
          ),
          const SizedBox(height: 12),
          TextField(controller: amount, decoration: const InputDecoration(labelText: 'Amount')),
          const SizedBox(height: 12),
          TextField(controller: sender, decoration: const InputDecoration(labelText: 'Sender account')),
          const SizedBox(height: 12),
          TextField(controller: txid, decoration: const InputDecoration(labelText: 'Transaction ID')),
          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: loading ? null : () async {
              setState(() => loading = true)

              try {
                final res = await api.submitRecharge(
                  userId: 'u1',
                  amount: int.tryParse(amount.text.trim()) ?? 0,
                  method: method,
                  senderAccount: sender.text.trim(),
                  transactionId: txid.text.trim(),
                );
                if (!mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text(res['message']?.toString() ?? 'Recharge request sent')),
                );
              } finally {
                if (mounted) setState(() => loading = false);
              }
            },
            child: const Text('Submit request'),
          )
        ],
      ),
    );
  }
}
