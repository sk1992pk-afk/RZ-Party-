import 'package:flutter/material.dart';

class RechargeHistoryScreen extends StatelessWidget {
  const RechargeHistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final items = const [
      {'amount': '1000 PKR', 'status': 'pending', 'method': 'JazzCash'},
      {'amount': '5000 PKR', 'status': 'approved', 'method': 'EasyPaisa'},
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('Recharge History')),
      body: ListView.builder(
        itemCount: items.length,
        itemBuilder: (_, i) => ListTile(
          title: Text(items[i]['amount']!),
          subtitle: Text(items[i]['method']!),
          trailing: Text(items[i]['status']!),
        ),
      ),
    );
  }
}
