import 'package:flutter/foundation.dart';
import '../../services/auth_api_service.dart';
import '../app/app_state.dart';

class AuthProvider extends ChangeNotifier {
  final AuthApiService api;
  final AppState appState;
  AuthProvider(this.api, this.appState);

  bool loading = false;
  String? error;

  Future<bool> login(String phone, String password) async {
    loading = true;
    error = null;
    notifyListeners();
    try {
      final res = await api.login(phone: phone, password: password);
      final token = res['token']?.toString();
      final userId = res['user']?['id']?.toString();
      if (token != null && userId != null) {
        await appState.setSession(token, userId);
        return true;
      }
      error = 'Login failed';
      return false;
    } catch (e) {
      error = e.toString();
      return false;
    } finally {
      loading = false;
      notifyListeners();
    }
  }
}
