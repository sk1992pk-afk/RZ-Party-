import 'package:flutter/foundation.dart';
import '../../core/storage/session_storage.dart';

class AppState extends ChangeNotifier {
  final SessionStorage storage;
  AppState(this.storage);

  bool _initialized = false;
  bool _loggedIn = false;
  String? _token;
  String? _userId;

  bool get initialized => _initialized;
  bool get loggedIn => _loggedIn;
  String? get token => _token;
  String? get userId => _userId;

  Future<void> bootstrap() async {
    _token = await storage.getToken();
    _userId = await storage.getUserId();
    _loggedIn = _token != null && _userId != null;
    _initialized = true;
    notifyListeners();
  }

  Future<void> setSession(String token, String userId) async {
    await storage.saveSession(token: token, userId: userId);
    _token = token;
    _userId = userId;
    _loggedIn = true;
    notifyListeners();
  }

  Future<void> logout() async {
    await storage.clear();
    _token = null;
    _userId = null;
    _loggedIn = false;
    notifyListeners();
  }
}
