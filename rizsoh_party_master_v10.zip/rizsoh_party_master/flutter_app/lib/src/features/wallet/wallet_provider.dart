import 'package:flutter/foundation.dart';
import '../../services/wallet_api_service.dart';

class WalletProvider extends ChangeNotifier {
  final WalletApiService api;
  WalletProvider(this.api);

  List<dynamic> transactions = [];
  bool loading = false;

  Future<void> loadTransactions() async {
    loading = true;
    notifyListeners();
    try {
      transactions = await api.getTransactions();
    } finally {
      loading = false;
      notifyListeners();
    }
  }
}
