# Rizsoh Party Master

Current scaffold now includes:

## Flutter
- auth + home + rooms + room detail + live + chat + profile + wallet + family + agency + recharge
- live host prototype
- VIP benefits screen
- room moderation panel scaffold

## Backend
- in-memory DB foundation for users/rooms/families/agencies/gifts/transactions/settlements
- wallet service
- gift transaction service
- room moderation service
- VIP service
- settlement service
- payment approval actions
- moderation / VIP / settlement / advanced gift routes

## Admin
- moderation page
- settlements page
- VIP levels page
- gift transactions page
- payment approval actions page

This is still a scaffold / master source prototype, not yet a final production app.
