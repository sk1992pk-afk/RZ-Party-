const router = require('express').Router();
const { db, makeId } = require('../../db/inMemoryDb');

router.get('/methods', async (req, res) => {
  res.json([
    { code: 'jazzcash', name: 'JazzCash', type: 'manual' },
    { code: 'easypaisa', name: 'EasyPaisa', type: 'manual' }
  ]);
});

router.post('/recharge-request', async (req, res) => {
  const { userId = 'u1', amount, method, senderAccount, transactionId } = req.body;
  const row = {
    id: makeId('recharge'),
    userId,
    amount,
    method,
    senderAccount,
    transactionId,
    status: 'pending',
    createdAt: new Date().toISOString()
  };
  db.rechargeRequests.unshift(row);
  res.json({ message: 'Recharge request submitted', request: row });
});

router.post('/withdraw-request', async (req, res) => {
  const { userId = 'u2', amount, method, accountTitle, accountNumber } = req.body;
  const row = {
    id: makeId('withdraw'),
    userId,
    amount,
    method,
    accountTitle,
    accountNumber,
    status: 'pending',
    createdAt: new Date().toISOString()
  };
  db.withdrawRequests.unshift(row);
  res.json({ message: 'Withdraw request submitted', request: row });
});

module.exports = router;
