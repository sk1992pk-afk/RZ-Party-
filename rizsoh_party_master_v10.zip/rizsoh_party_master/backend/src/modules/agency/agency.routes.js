const router = require('express').Router();

router.get('/me', async (req, res) => {
  res.json({
    agencyId: 'a1',
    name: 'Rizsoh Elite Agency',
    hosts: 14,
    monthlyIncome: 125000,
    pendingApplications: 3,
  });
});

router.get('/settlements', async (req, res) => {
  res.json([
    { id: 's1', month: '2026-07', amount: 50000, status: 'paid' },
    { id: 's2', month: '2026-08', amount: 62000, status: 'pending' }
  ]);
});

module.exports = router;
