const router = require('express').Router();

router.get('/', async (req, res) => {
  res.json([
    { id: 'f1', name: 'Rizsoh Royals', level: 5, members: 32 },
    { id: 'f2', name: 'Pink Hearts', level: 3, members: 18 }
  ]);
});

router.post('/join', async (req, res) => {
  res.json({ message: 'family join request submitted', payload: req.body });
});

module.exports = router;
