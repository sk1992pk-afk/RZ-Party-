const router = require('express').Router();

router.put('/me', async (req, res) => {
  res.json({ message: 'Profile updated', profile: req.body });
});

router.get('/badges', async (req, res) => {
  res.json([
    { code: 'vip3', label: 'VIP 3' },
    { code: 'lvl12', label: 'Level 12' },
    { code: 'family_member', label: 'Family Member' }
  ]);
});

module.exports = router;
