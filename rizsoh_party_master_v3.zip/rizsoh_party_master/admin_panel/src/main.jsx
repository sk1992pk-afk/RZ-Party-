import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom'
import UsersPage from './pages/UsersPage'
import RoomsPage from './pages/RoomsPage'
import WalletPage from './pages/WalletPage'
import FamiliesPage from './pages/FamiliesPage'
import WithdrawalsPage from './pages/WithdrawalsPage'

function Dashboard() {
  return (
    <div style={{padding:24}}>
      <h1>Rizsoh Party Admin</h1>
      <p>Dashboard for users, rooms, live, gifts, families, recharge, withdrawals and moderation.</p>
    </div>
  )
}

function App() {
  return (
    <BrowserRouter>
      <div style={{display:'flex', minHeight:'100vh'}}>
        <aside style={{width:260, borderRight:'1px solid #eee', padding:16}}>
          <h3>Admin Panel</h3>
          <div style={{display:'grid', gap:10}}>
            <Link to="/">Dashboard</Link>
            <Link to="/users">Users</Link>
            <Link to="/rooms">Rooms</Link>
            <Link to="/wallet">Wallet</Link>
            <Link to="/families">Families</Link>
            <Link to="/withdrawals">Withdrawals</Link>
          </div>
        </aside>
        <main style={{flex:1}}>
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/users" element={<UsersPage />} />
            <Route path="/rooms" element={<RoomsPage />} />
            <Route path="/wallet" element={<WalletPage />} />
            <Route path="/families" element={<FamiliesPage />} />
            <Route path="/withdrawals" element={<WithdrawalsPage />} />
          </Routes>
        </main>
      </div>
    </BrowserRouter>
  )
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />)
