import 'package:flutter/material.dart';

class GiftBottomSheet extends StatelessWidget {
  const GiftBottomSheet({super.key});

  @override
  Widget build(BuildContext context) {
    final gifts = const [
      {'name': 'Rose', 'price': '99'},
      {'name': 'Crown', 'price': '999'},
      {'name': 'Castle', 'price': '4999'},
    ];

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Text('Send Gift', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          SizedBox(
            height: 180,
            child: GridView.count(
              crossAxisCount: 3,
              children: gifts.map((g) => Card(
                child: InkWell(
                  onTap: () => Navigator.pop(context, g),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.card_giftcard, size: 32),
                      const SizedBox(height: 8),
                      Text(g['name']!),
                      Text('${g['price']} coins'),
                    ],
                  ),
                ),
              )).toList(),
            ),
          ),
        ],
      ),
    );
  }
}
