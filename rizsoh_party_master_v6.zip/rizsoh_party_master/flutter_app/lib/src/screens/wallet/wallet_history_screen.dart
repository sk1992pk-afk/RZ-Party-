import 'package:flutter/material.dart';

class WalletHistoryScreen extends StatelessWidget {
  const WalletHistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final tx = const [
      {'title': 'Gift sent', 'amount': '-999 coins', 'time': '2m ago'},
      {'title': 'Recharge approved', 'amount': '+2000 coins', 'time': '1h ago'},
      {'title': 'Gift received', 'amount': '+500 diamonds', 'time': '3h ago'},
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('Wallet History')),
      body: ListView.builder(
        itemCount: tx.length,
        itemBuilder: (_, i) => ListTile(
          title: Text(tx[i]['title']!),
          subtitle: Text(tx[i]['time']!),
          trailing: Text(tx[i]['amount']!),
        ),
      ),
    );
  }
}
