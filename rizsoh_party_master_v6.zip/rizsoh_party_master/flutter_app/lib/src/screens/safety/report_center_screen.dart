import 'package:flutter/material.dart';

class ReportCenterScreen extends StatelessWidget {
  const ReportCenterScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final reports = const [
      {'type': 'User report', 'reason': 'Abusive language', 'status': 'pending'},
      {'type': 'Room report', 'reason': 'Harassment', 'status': 'reviewed'},
      {'type': 'Live report', 'reason': 'Spam content', 'status': 'pending'},
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Safety Reports')),
      body: ListView.builder(
        itemCount: reports.length,
        itemBuilder: (_, i) => ListTile(
          title: Text(reports[i]['type']!),
          subtitle: Text(reports[i]['reason']!),
          trailing: Text(reports[i]['status']!),
        ),
      ),
    );
  }
}
