const express = require('express');
const cors = require('cors');
const http = require('http');
const { Server } = require('socket.io');

const authRoutes = require('./modules/auth/auth.routes');
const userRoutes = require('./modules/users/user.routes');
const profileRoutes = require('./modules/profile/profile.routes');
const roomRoutes = require('./modules/rooms/room.routes');
const roomModerationRoutes = require('./modules/rooms/moderation.routes');
const liveRoutes = require('./modules/live/live.routes');
const liveHostRoutes = require('./modules/live/live.host.routes');
const walletRoutes = require('./modules/wallet/wallet.routes');
const txRoutes = require('./modules/wallet/transactions.routes');
const chatRoutes = require('./modules/chat/chat.routes');
const giftRoutes = require('./modules/gifts/gift.routes');
const giftTxRoutes = require('./modules/gifts/gift.transaction.routes');
const familyRoutes = require('./modules/family/family.routes');
const agencyRoutes = require('./modules/agency/agency.routes');
const settlementRoutes = require('./modules/settlements/settlement.routes');
const paymentRoutes = require('./modules/payments/payment.routes');
const paymentReviewActionRoutes = require('./modules/payments/review.actions.routes');
const pushRoutes = require('./modules/push/push.routes');
const vipRoutes = require('./modules/vip/vip.routes');
const adminRoutes = require('./modules/admin/admin.routes');
const adminReviewRoutes = require('./modules/admin/review.routes');
const reportRoutes = require('./modules/reports/report.routes');

const app = express();
app.use(cors());
app.use(express.json());

app.get('/health', (req, res) => res.json({ ok: true, app: 'Rizsoh Party API' }));

app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/profile', profileRoutes);
app.use('/api/rooms', roomRoutes);
app.use('/api/rooms/moderation', roomModerationRoutes);
app.use('/api/live', liveRoutes);
app.use('/api/live', liveHostRoutes);
app.use('/api/wallet', walletRoutes);
app.use('/api/wallet/transactions', txRoutes);
app.use('/api/chat', chatRoutes);
app.use('/api/gifts', giftRoutes);
app.use('/api/gifts', giftTxRoutes);
app.use('/api/families', familyRoutes);
app.use('/api/agency', agencyRoutes);
app.use('/api/settlements', settlementRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/payments/review', paymentReviewActionRoutes);
app.use('/api/push', pushRoutes);
app.use('/api/vip', vipRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/admin/review', adminReviewRoutes);
app.use('/api/reports', reportRoutes);

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

io.on('connection', (socket) => {
  socket.on('room:join', ({ roomId, user }) => {
    socket.join(`room:${roomId}`);
    io.to(`room:${roomId}`).emit('room:user_joined', { roomId, user });
  });

  socket.on('room:gift', (payload) => {
    io.to(`room:${payload.roomId}`).emit('room:gift_sent', { ...payload, at: Date.now() });
  });

  socket.on('room:mute', (payload) => {
    io.to(`room:${payload.roomId}`).emit('room:user_muted', payload);
  });

  socket.on('room:kick', (payload) => {
    io.to(`room:${payload.roomId}`).emit('room:user_kicked', payload);
  });

  socket.on('room:ban', (payload) => {
    io.to(`room:${payload.roomId}`).emit('room:user_banned', payload);
  });

  socket.on('live:comment', ({ liveId, user, message }) => {
    io.emit('live:comment_added', { liveId, user, message });
  });

  socket.on('push:test', ({ userId, title, body }) => {
    io.emit('push:preview', { userId, title, body });
  });
});

const PORT = process.env.PORT || 4000;
server.listen(PORT, () => console.log(`Rizsoh backend running on ${PORT}`));
