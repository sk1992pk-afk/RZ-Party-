const router = require('express').Router();
const { db, makeId } = require('../../db/inMemoryDb');

router.get('/', async (req, res) => {
  res.json(db.reports);
});

router.post('/', async (req, res) => {
  const row = {
    id: makeId('report'),
    type: req.body.type || 'user',
    targetId: req.body.targetId || '',
    reason: req.body.reason || '',
    status: 'pending',
    createdAt: new Date().toISOString()
  };
  db.reports.unshift(row);
  res.json({ message: 'report submitted', report: row });
});

module.exports = router;
