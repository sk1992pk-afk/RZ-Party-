export default function ReportsTablePage() {
  const rows = [
    { id: 'rep_1', type: 'user', target: 'u2', reason: 'abuse', status: 'pending' },
    { id: 'rep_2', type: 'room', target: 'r1', reason: 'spam', status: 'reviewed' },
  ];

  return (
    <div style={{padding:24}}>
      <h2>Reports Data Table</h2>
      <table border="1" cellPadding="8" style={{borderCollapse:'collapse', width:'100%'}}>
        <thead>
          <tr><th>ID</th><th>Type</th><th>Target</th><th>Reason</th><th>Status</th></tr>
        </thead>
        <tbody>
          {rows.map(r => (
            <tr key={r.id}>
              <td>{r.id}</td><td>{r.type}</td><td>{r.target}</td><td>{r.reason}</td><td>{r.status}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
