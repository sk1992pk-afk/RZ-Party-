import 'package:flutter/material.dart';

class ReportSubmitScreen extends StatefulWidget {
  final String targetId;
  final String type;
  const ReportSubmitScreen({super.key, required this.targetId, required this.type});

  @override
  State<ReportSubmitScreen> createState() => _ReportSubmitScreenState();
}

class _ReportSubmitScreenState extends State<ReportSubmitScreen> {
  final controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Submit Report')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Text('Report ${widget.type}: ${widget.targetId}'),
            const SizedBox(height: 12),
            TextField(
              controller: controller,
              maxLines: 5,
              decoration: const InputDecoration(
                hintText: 'Describe the issue',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Report submit flow scaffold ready')),
                );
              },
              child: const Text('Submit report'),
            )
          ],
        ),
      ),
    );
  }
}
