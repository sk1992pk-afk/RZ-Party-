import 'package:flutter/material.dart';
import '../../widgets/gifts/gift_bottom_sheet.dart';

class LiveRoomScreen extends StatefulWidget {
  const LiveRoomScreen({super.key});

  @override
  State<LiveRoomScreen> createState() => _LiveRoomScreenState();
}

class _LiveRoomScreenState extends State<LiveRoomScreen> {
  final comments = <String>['Welcome to Rizsoh live'];
  final controller = TextEditingController();

  void _openGiftSheet() {
    showModalBottomSheet(
      context: context,
      builder: (_) => GiftBottomSheet(
        onSelected: (gift) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Selected ${gift['name']}')),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Live Room')),
      body: Stack(
        children: [
          Container(color: const Color(0xFFFDF1F6)),
          Positioned(
            left: 12, right: 12, bottom: 80, top: 12,
            child: ListView(
              children: comments.map((e) => Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Text(e),
              )).toList(),
            ),
          ),
          Positioned(
            left: 12, right: 12, bottom: 12,
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: controller,
                    decoration: const InputDecoration(
                      hintText: 'Write comment',
                      filled: true,
                    ),
                    onSubmitted: (v) {
                      if (v.trim().isEmpty) return;
                      setState(() => comments.add(v.trim()));
                      controller.clear();
                    },
                  ),
                ),
                IconButton(onPressed: _openGiftSheet, icon: const Icon(Icons.card_giftcard)),
              ],
            ),
          )
        ],
      ),
    );
  }
}
