import 'package:flutter/material.dart';
import '../agency/agency_center_screen.dart';
import '../family/family_center_screen.dart';
import '../payments/recharge_screen.dart';
import '../wallet/wallet_screen.dart';
import 'edit_profile_screen.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('My Profile')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const CircleAvatar(radius: 40, child: Icon(Icons.person, size: 40)),
          const SizedBox(height: 12),
          const Center(child: Text('Rizsoh User', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
          const SizedBox(height: 8),
          const Center(child: Text('ID: 100001 • VIP 3 • Level 12')),
          const SizedBox(height: 20),
          ListTile(title: const Text('Edit Profile'), trailing: const Icon(Icons.chevron_right), onTap: (){
            Navigator.push(context, MaterialPageRoute(builder: (_) => const EditProfileScreen()));
          }),
          ListTile(title: const Text('Wallet'), trailing: const Icon(Icons.chevron_right), onTap: (){
            Navigator.push(context, MaterialPageRoute(builder: (_) => const WalletScreen()));
          }),
          ListTile(title: const Text('Recharge'), trailing: const Icon(Icons.chevron_right), onTap: (){
            Navigator.push(context, MaterialPageRoute(builder: (_) => const RechargeScreen()));
          }),
          ListTile(title: const Text('Family Center'), trailing: const Icon(Icons.chevron_right), onTap: (){
            Navigator.push(context, MaterialPageRoute(builder: (_) => const FamilyCenterScreen()));
          }),
          ListTile(title: const Text('Agency Center'), trailing: const Icon(Icons.chevron_right), onTap: (){
            Navigator.push(context, MaterialPageRoute(builder: (_) => const AgencyCenterScreen()));
          }),
        ],
      ),
    );
  }
}
