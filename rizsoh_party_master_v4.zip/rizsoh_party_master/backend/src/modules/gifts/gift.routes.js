const router = require('express').Router();

router.get('/mall', async (req, res) => {
  res.json([
    { id: 'g1', name: 'Rose', price: 99, category: 'basic' },
    { id: 'g2', name: 'Crown', price: 999, category: 'premium' },
    { id: 'g3', name: 'Castle', price: 4999, category: 'luxury' }
  ]);
});

router.post('/send', async (req, res) => {
  const { targetType, targetId, giftId, qty = 1 } = req.body;
  res.json({ message: 'gift sent', targetType, targetId, giftId, qty });
});

module.exports = router;
