const router = require('express').Router();

router.get('/methods', async (req, res) => {
  res.json([
    { code: 'jazzcash', name: 'JazzCash', type: 'manual' },
    { code: 'easypaisa', name: 'EasyPaisa', type: 'manual' }
  ]);
});

router.post('/recharge-request', async (req, res) => {
  const { amount, method, senderAccount, transactionId } = req.body;
  res.json({
    message: 'Recharge request submitted',
    request: { amount, method, senderAccount, transactionId, status: 'pending' }
  });
});

router.post('/withdraw-request', async (req, res) => {
  const { amount, method, accountTitle, accountNumber } = req.body;
  res.json({
    message: 'Withdraw request submitted',
    request: { amount, method, accountTitle, accountNumber, status: 'pending' }
  });
});

module.exports = router;
