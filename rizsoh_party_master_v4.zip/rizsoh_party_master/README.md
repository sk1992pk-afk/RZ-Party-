# Rizsoh Party Master

Current scaffold includes:
- Flutter app foundation + explore/rooms/live/messages/profile
- Room detail prototype with seat layout
- Wallet screen, Family center, Gift mall
- Node backend routes for auth, users, rooms, live, wallet, chat, gifts, families, admin
- Socket events for join/gift/mute/kick
- React admin pages for users, rooms, wallet, families, withdrawals

This is still a scaffold/prototype codebase, not a production-complete clone.
