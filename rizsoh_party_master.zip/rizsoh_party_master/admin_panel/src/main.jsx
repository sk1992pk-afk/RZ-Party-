import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom'

function Dashboard() {
  return (
    <div style={{padding:24}}>
      <h1>Rizsoh Party Admin</h1>
      <p>Users, rooms, live, wallet, recharge, withdrawals, reports and agencies will be managed here.</p>
    </div>
  )
}

function App() {
  return (
    <BrowserRouter>
      <nav style={{padding:16, borderBottom:'1px solid #eee'}}>
        <Link to="/">Dashboard</Link>
      </nav>
      <Routes>
        <Route path="/" element={<Dashboard />} />
      </Routes>
    </BrowserRouter>
  )
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />)
