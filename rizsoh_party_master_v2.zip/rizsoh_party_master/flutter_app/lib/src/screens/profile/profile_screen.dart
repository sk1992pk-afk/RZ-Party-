import 'package:flutter/material.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('My Profile')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: const [
          CircleAvatar(radius: 40, child: Icon(Icons.person, size: 40)),
          SizedBox(height: 12),
          Center(child: Text('Rizsoh User', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
          SizedBox(height: 8),
          Center(child: Text('ID: 100001')),
          SizedBox(height: 20),
          ListTile(title: Text('Wallet'), trailing: Icon(Icons.chevron_right)),
          ListTile(title: Text('Family Center'), trailing: Icon(Icons.chevron_right)),
          ListTile(title: Text('Agency Center'), trailing: Icon(Icons.chevron_right)),
          ListTile(title: Text('Settings'), trailing: Icon(Icons.chevron_right)),
        ],
      ),
    );
  }
}
