const router = require('express').Router();

router.get('/me', async (req, res) => {
  res.json({
    coins: 500,
    diamonds: 120,
    earnings: 3000,
    rechargeRequests: [],
    withdrawals: []
  });
});

router.post('/recharge/manual', async (req, res) => {
  res.json({ message: 'manual recharge request submitted', payload: req.body });
});

router.post('/withdraw', async (req, res) => {
  res.json({ message: 'withdraw request submitted', payload: req.body });
});

module.exports = router;
