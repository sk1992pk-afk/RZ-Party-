const router = require('express').Router();

router.get('/', async (req, res) => {
  res.json([
    { id: 'l1', host: 'Host Live 1', title: 'Night Talk', viewers: 230 },
    { id: 'l2', host: 'Host Live 2', title: 'Music Live', viewers: 150 }
  ]);
});

router.post('/start', async (req, res) => {
  res.json({ message: 'live started', live: req.body });
});

module.exports = router;
