const router = require('express').Router();

router.post('/signup', async (req, res) => {
  res.json({ message: 'signup endpoint scaffold', data: req.body });
});

router.post('/login', async (req, res) => {
  res.json({ token: 'demo-token', user: { id: '1', name: 'Demo User' } });
});

module.exports = router;
