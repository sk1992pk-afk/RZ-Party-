const router = require('express').Router();

router.get('/', async (req, res) => {
  res.json([
    { id: 'r1', name: 'Luxury Room 1', host: 'Host 1', members: 24, locked: false },
    { id: 'r2', name: 'Music Room', host: 'Host 2', members: 15, locked: true }
  ]);
});

router.post('/', async (req, res) => {
  res.json({ message: 'room created', room: req.body });
});

router.post('/:roomId/join', async (req, res) => {
  res.json({ message: `joined room ${req.params.roomId}` });
});

module.exports = router;
