const router = require('express').Router();

router.get('/conversations', async (req, res) => {
  res.json([{ id: 'c1', user: 'Sara', lastMessage: 'Hello' }]);
});

module.exports = router;
