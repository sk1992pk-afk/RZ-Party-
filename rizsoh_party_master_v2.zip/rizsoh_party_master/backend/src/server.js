const express = require('express');
const cors = require('cors');
const http = require('http');
const { Server } = require('socket.io');

const authRoutes = require('./modules/auth/auth.routes');
const userRoutes = require('./modules/users/user.routes');
const roomRoutes = require('./modules/rooms/room.routes');
const liveRoutes = require('./modules/live/live.routes');
const walletRoutes = require('./modules/wallet/wallet.routes');
const chatRoutes = require('./modules/chat/chat.routes');

const app = express();
app.use(cors());
app.use(express.json());

app.get('/health', (req, res) => res.json({ ok: true, app: 'Rizsoh Party API' }));

app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/rooms', roomRoutes);
app.use('/api/live', liveRoutes);
app.use('/api/wallet', walletRoutes);
app.use('/api/chat', chatRoutes);

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

io.on('connection', (socket) => {
  console.log('socket connected', socket.id);

  socket.on('room:join', ({ roomId, user }) => {
    socket.join(`room:${roomId}`);
    io.to(`room:${roomId}`).emit('room:user_joined', { roomId, user });
  });

  socket.on('room:gift', ({ roomId, gift, fromUser }) => {
    io.to(`room:${roomId}`).emit('room:gift_sent', { roomId, gift, fromUser });
  });

  socket.on('live:comment', ({ liveId, user, message }) => {
    io.emit('live:comment_added', { liveId, user, message });
  });
});

const PORT = process.env.PORT || 4000;
server.listen(PORT, () => console.log(`Rizsoh backend running on ${PORT}`));
