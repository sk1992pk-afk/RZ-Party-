# Rizsoh Party Master

Starter master scaffold for **Rizsoh Party**  
Package: `com.rizsoh.party`

Includes:
- Flutter app scaffold
- Node.js backend scaffold
- React admin panel scaffold
- Theme + auth + routing foundation
- Realtime / wallet / room / live module placeholders

This is the initial master source package generated from chat. It is a **foundation scaffold** and can be expanded block-by-block.
